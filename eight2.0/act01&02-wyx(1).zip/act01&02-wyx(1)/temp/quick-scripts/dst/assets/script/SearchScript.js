
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/SearchScript.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '352c4gQ66pMZobBoHL/mkjj', 'SearchScript');
// script/SearchScript.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Textindex: cc.Integer
  },
  onLoad: function onLoad() {
    this.Textindex = 0;
    this.node.active = false;
    this.node.getChildByName("Button1").active = false;
    this.node.getChildByName("Button2").active = false;
    this.node.getChildByName("Button3").active = false;
    cc.systemEvent.on('keydown', this.onKeyDown, this); //绑定键盘
  },
  onDestroy: function onDestroy() {
    cc.systemEvent.off('keydown', this.onKeyDown, this);
  },
  onKeyDown: function onKeyDown(e) {
    switch (e.keyCode) {
      case cc.macro.KEY.space:
        {
          this.closeText();
          break;
        }
    }
  },
  on_btn_onclick_phone: function on_btn_onclick_phone() {
    this.node.active = true;
    var str = "怎么是星期八？信号也没了，破手机肯定是坏了，该换台新的了。";
    var j = 0;
    this.node.getChildByName("TextLabel").getComponent(cc.Label).string = "";
    this.schedule(function () {
      this.node.getChildByName("TextLabel").getComponent(cc.Label).string += str[j];
      j++;
    }, 0.1, str.length - 1, 0.2);
  },
  on_btn_onclick_laptop: function on_btn_onclick_laptop() {
    this.node.active = true;
    var str = "你的电脑烫得动不了，似乎在运行复杂的程序。";
    var j = 0;
    this.node.getChildByName("TextLabel").getComponent(cc.Label).string = "";
    this.schedule(function () {
      this.node.getChildByName("TextLabel").getComponent(cc.Label).string += str[j];
      j++;
    }, 0.1, str.length - 1, 0.2);
  },
  on_btn_onclick_door: function on_btn_onclick_door() {
    this.node.active = true;
    var str = "门被锁上了，需要钥匙才能打开。";
    var j = 0;
    this.node.getChildByName("TextLabel").getComponent(cc.Label).string = "";
    this.schedule(function () {
      this.node.getChildByName("TextLabel").getComponent(cc.Label).string += str[j];
      j++;
    }, 0.1, str.length - 1, 0.2);
  },
  on_btn_onclick_window: function on_btn_onclick_window() {
    this.Textindex = 0;
    this.node.active = true;
    var str = "窗户半开着。";
    this.node.getChildByName("TextLabel").getComponent(cc.Label).string = "";
    this.schedule(function () {
      this.node.getChildByName("TextLabel").getComponent(cc.Label).string += str[this.Textindex];
      this.Textindex++;
    }, 0.1, str.length - 1, 0.2);
  },
  on_btn_onclick_desk: function on_btn_onclick_desk() {
    //场景切换到堆桌子小游戏
    cc.director.loadScene("Game");
  },
  closeText: function closeText() {
    cc.log(this.Textindex);

    if (this.Textindex == 6) {
      this.node.getChildByName("Button1").active = true;
      this.node.getChildByName("Button2").active = true;
      this.node.getChildByName("Button3").active = true;
    } else {
      if (this.Textindex == 0) {
        this.node.active = false;
      }
    }

    this.Textindex = 0;
  },
  onclick_Button1: function onclick_Button1() {
    cc.director.loadScene("Scene 2.31"); //场景切换到Scene2.31

    cc.log("change to Scene 2.31");
  },
  onclick_Button2: function onclick_Button2() {
    this.node.getChildByName("Button1").active = false;
    this.node.getChildByName("Button2").active = false;
    this.node.getChildByName("Button3").active = false;
    var str = "没有人应答。";
    var j = 0;
    this.node.getChildByName("TextLabel").getComponent(cc.Label).string = "";
    this.schedule(function () {
      this.node.getChildByName("TextLabel").getComponent(cc.Label).string += str[j];
      j++;
    }, 0.1, str.length - 1, 0.2);
  },
  onclick_Button3: function onclick_Button3() {
    this.node.getChildByName("Button1").active = false;
    this.node.getChildByName("Button2").active = false;
    this.node.getChildByName("Button3").active = false;
    this.node.active = false;
  },
  // LIFE-CYCLE CALLBACKS:
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxTZWFyY2hTY3JpcHQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJUZXh0aW5kZXgiLCJJbnRlZ2VyIiwib25Mb2FkIiwibm9kZSIsImFjdGl2ZSIsImdldENoaWxkQnlOYW1lIiwic3lzdGVtRXZlbnQiLCJvbiIsIm9uS2V5RG93biIsIm9uRGVzdHJveSIsIm9mZiIsImUiLCJrZXlDb2RlIiwibWFjcm8iLCJLRVkiLCJzcGFjZSIsImNsb3NlVGV4dCIsIm9uX2J0bl9vbmNsaWNrX3Bob25lIiwic3RyIiwiaiIsImdldENvbXBvbmVudCIsIkxhYmVsIiwic3RyaW5nIiwic2NoZWR1bGUiLCJsZW5ndGgiLCJvbl9idG5fb25jbGlja19sYXB0b3AiLCJvbl9idG5fb25jbGlja19kb29yIiwib25fYnRuX29uY2xpY2tfd2luZG93Iiwib25fYnRuX29uY2xpY2tfZGVzayIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwibG9nIiwib25jbGlja19CdXR0b24xIiwib25jbGlja19CdXR0b24yIiwib25jbGlja19CdXR0b24zIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxTQUFTLEVBQUNKLEVBQUUsQ0FBQ0s7QUFETCxHQUhQO0FBT0xDLEVBQUFBLE1BUEssb0JBT0s7QUFDTixTQUFLRixTQUFMLEdBQWlCLENBQWpCO0FBQ0EsU0FBS0csSUFBTCxDQUFVQyxNQUFWLEdBQW1CLEtBQW5CO0FBQ0EsU0FBS0QsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFNBQXpCLEVBQW9DRCxNQUFwQyxHQUE2QyxLQUE3QztBQUNBLFNBQUtELElBQUwsQ0FBVUUsY0FBVixDQUF5QixTQUF6QixFQUFvQ0QsTUFBcEMsR0FBNkMsS0FBN0M7QUFDQSxTQUFLRCxJQUFMLENBQVVFLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NELE1BQXBDLEdBQTZDLEtBQTdDO0FBQ0FSLElBQUFBLEVBQUUsQ0FBQ1UsV0FBSCxDQUFlQyxFQUFmLENBQWtCLFNBQWxCLEVBQTRCLEtBQUtDLFNBQWpDLEVBQTJDLElBQTNDLEVBTk0sQ0FNMkM7QUFDcEQsR0FkSTtBQWVMQyxFQUFBQSxTQWZLLHVCQWVNO0FBQ1BiLElBQUFBLEVBQUUsQ0FBQ1UsV0FBSCxDQUFlSSxHQUFmLENBQW1CLFNBQW5CLEVBQTZCLEtBQUtGLFNBQWxDLEVBQTRDLElBQTVDO0FBQ0gsR0FqQkk7QUFrQkxBLEVBQUFBLFNBbEJLLHFCQWtCS0csQ0FsQkwsRUFrQk87QUFDUixZQUFPQSxDQUFDLENBQUNDLE9BQVQ7QUFDSSxXQUFLaEIsRUFBRSxDQUFDaUIsS0FBSCxDQUFTQyxHQUFULENBQWFDLEtBQWxCO0FBQXdCO0FBQ3BCLGVBQUtDLFNBQUw7QUFDQTtBQUNIO0FBSkw7QUFNSCxHQXpCSTtBQTRCTEMsRUFBQUEsb0JBQW9CLEVBQUMsZ0NBQVU7QUFDM0IsU0FBS2QsSUFBTCxDQUFVQyxNQUFWLEdBQW1CLElBQW5CO0FBQ0EsUUFBSWMsR0FBRyxHQUFHLCtCQUFWO0FBQ0EsUUFBSUMsQ0FBQyxHQUFHLENBQVI7QUFDQSxTQUFLaEIsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFdBQXpCLEVBQXNDZSxZQUF0QyxDQUFtRHhCLEVBQUUsQ0FBQ3lCLEtBQXRELEVBQTZEQyxNQUE3RCxHQUFzRSxFQUF0RTtBQUNBLFNBQUtDLFFBQUwsQ0FBYyxZQUFVO0FBQ3BCLFdBQUtwQixJQUFMLENBQVVFLGNBQVYsQ0FBeUIsV0FBekIsRUFBc0NlLFlBQXRDLENBQW1EeEIsRUFBRSxDQUFDeUIsS0FBdEQsRUFBNkRDLE1BQTdELElBQXVFSixHQUFHLENBQUNDLENBQUQsQ0FBMUU7QUFDQUEsTUFBQUEsQ0FBQztBQUNKLEtBSEQsRUFHRyxHQUhILEVBR1FELEdBQUcsQ0FBQ00sTUFBSixHQUFXLENBSG5CLEVBR3NCLEdBSHRCO0FBSUgsR0FyQ0k7QUF1Q0xDLEVBQUFBLHFCQUFxQixFQUFDLGlDQUFVO0FBQzVCLFNBQUt0QixJQUFMLENBQVVDLE1BQVYsR0FBbUIsSUFBbkI7QUFDQSxRQUFJYyxHQUFHLEdBQUcsdUJBQVY7QUFDQSxRQUFJQyxDQUFDLEdBQUcsQ0FBUjtBQUNBLFNBQUtoQixJQUFMLENBQVVFLGNBQVYsQ0FBeUIsV0FBekIsRUFBc0NlLFlBQXRDLENBQW1EeEIsRUFBRSxDQUFDeUIsS0FBdEQsRUFBNkRDLE1BQTdELEdBQXNFLEVBQXRFO0FBQ0EsU0FBS0MsUUFBTCxDQUFjLFlBQVU7QUFDcEIsV0FBS3BCLElBQUwsQ0FBVUUsY0FBVixDQUF5QixXQUF6QixFQUFzQ2UsWUFBdEMsQ0FBbUR4QixFQUFFLENBQUN5QixLQUF0RCxFQUE2REMsTUFBN0QsSUFBdUVKLEdBQUcsQ0FBQ0MsQ0FBRCxDQUExRTtBQUNBQSxNQUFBQSxDQUFDO0FBQ0osS0FIRCxFQUdHLEdBSEgsRUFHUUQsR0FBRyxDQUFDTSxNQUFKLEdBQVcsQ0FIbkIsRUFHc0IsR0FIdEI7QUFJSCxHQWhESTtBQWtETEUsRUFBQUEsbUJBQW1CLEVBQUMsK0JBQVU7QUFDMUIsU0FBS3ZCLElBQUwsQ0FBVUMsTUFBVixHQUFtQixJQUFuQjtBQUNBLFFBQUljLEdBQUcsR0FBRyxpQkFBVjtBQUNBLFFBQUlDLENBQUMsR0FBRyxDQUFSO0FBQ0EsU0FBS2hCLElBQUwsQ0FBVUUsY0FBVixDQUF5QixXQUF6QixFQUFzQ2UsWUFBdEMsQ0FBbUR4QixFQUFFLENBQUN5QixLQUF0RCxFQUE2REMsTUFBN0QsR0FBc0UsRUFBdEU7QUFDQSxTQUFLQyxRQUFMLENBQWMsWUFBVTtBQUNwQixXQUFLcEIsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFdBQXpCLEVBQXNDZSxZQUF0QyxDQUFtRHhCLEVBQUUsQ0FBQ3lCLEtBQXRELEVBQTZEQyxNQUE3RCxJQUF1RUosR0FBRyxDQUFDQyxDQUFELENBQTFFO0FBQ0FBLE1BQUFBLENBQUM7QUFDSixLQUhELEVBR0csR0FISCxFQUdRRCxHQUFHLENBQUNNLE1BQUosR0FBVyxDQUhuQixFQUdzQixHQUh0QjtBQUlILEdBM0RJO0FBNkRMRyxFQUFBQSxxQkFBcUIsRUFBQyxpQ0FBVTtBQUM1QixTQUFLM0IsU0FBTCxHQUFpQixDQUFqQjtBQUNBLFNBQUtHLElBQUwsQ0FBVUMsTUFBVixHQUFtQixJQUFuQjtBQUNBLFFBQUljLEdBQUcsR0FBRyxRQUFWO0FBQ0EsU0FBS2YsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFdBQXpCLEVBQXNDZSxZQUF0QyxDQUFtRHhCLEVBQUUsQ0FBQ3lCLEtBQXRELEVBQTZEQyxNQUE3RCxHQUFzRSxFQUF0RTtBQUNBLFNBQUtDLFFBQUwsQ0FBYyxZQUFVO0FBQ3BCLFdBQUtwQixJQUFMLENBQVVFLGNBQVYsQ0FBeUIsV0FBekIsRUFBc0NlLFlBQXRDLENBQW1EeEIsRUFBRSxDQUFDeUIsS0FBdEQsRUFBNkRDLE1BQTdELElBQXVFSixHQUFHLENBQUMsS0FBS2xCLFNBQU4sQ0FBMUU7QUFDQSxXQUFLQSxTQUFMO0FBQ0gsS0FIRCxFQUdHLEdBSEgsRUFHUWtCLEdBQUcsQ0FBQ00sTUFBSixHQUFXLENBSG5CLEVBR3NCLEdBSHRCO0FBSUgsR0F0RUk7QUF3RUxJLEVBQUFBLG1CQUFtQixFQUFDLCtCQUFVO0FBQzFCO0FBQ0FoQyxJQUFBQSxFQUFFLENBQUNpQyxRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSCxHQTNFSTtBQTZFTGQsRUFBQUEsU0E3RUssdUJBNkVNO0FBQ1BwQixJQUFBQSxFQUFFLENBQUNtQyxHQUFILENBQU8sS0FBSy9CLFNBQVo7O0FBQ0EsUUFBRyxLQUFLQSxTQUFMLElBQWtCLENBQXJCLEVBQXVCO0FBQ25CLFdBQUtHLElBQUwsQ0FBVUUsY0FBVixDQUF5QixTQUF6QixFQUFvQ0QsTUFBcEMsR0FBNkMsSUFBN0M7QUFDQSxXQUFLRCxJQUFMLENBQVVFLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NELE1BQXBDLEdBQTZDLElBQTdDO0FBQ0EsV0FBS0QsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFNBQXpCLEVBQW9DRCxNQUFwQyxHQUE2QyxJQUE3QztBQUNILEtBSkQsTUFJSztBQUNELFVBQUcsS0FBS0osU0FBTCxJQUFrQixDQUFyQixFQUF3QjtBQUNwQixhQUFLRyxJQUFMLENBQVVDLE1BQVYsR0FBbUIsS0FBbkI7QUFDSDtBQUNKOztBQUNELFNBQUtKLFNBQUwsR0FBaUIsQ0FBakI7QUFDSCxHQXpGSTtBQTJGTGdDLEVBQUFBLGVBQWUsRUFBQywyQkFBVTtBQUN0QnBDLElBQUFBLEVBQUUsQ0FBQ2lDLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixZQUF0QixFQURzQixDQUNlOztBQUNyQ2xDLElBQUFBLEVBQUUsQ0FBQ21DLEdBQUgsQ0FBTyxzQkFBUDtBQUNILEdBOUZJO0FBZ0dMRSxFQUFBQSxlQUFlLEVBQUMsMkJBQVU7QUFDdEIsU0FBSzlCLElBQUwsQ0FBVUUsY0FBVixDQUF5QixTQUF6QixFQUFvQ0QsTUFBcEMsR0FBNkMsS0FBN0M7QUFDQSxTQUFLRCxJQUFMLENBQVVFLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NELE1BQXBDLEdBQTZDLEtBQTdDO0FBQ0EsU0FBS0QsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFNBQXpCLEVBQW9DRCxNQUFwQyxHQUE2QyxLQUE3QztBQUNBLFFBQUljLEdBQUcsR0FBRyxRQUFWO0FBQ0EsUUFBSUMsQ0FBQyxHQUFHLENBQVI7QUFDQSxTQUFLaEIsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFdBQXpCLEVBQXNDZSxZQUF0QyxDQUFtRHhCLEVBQUUsQ0FBQ3lCLEtBQXRELEVBQTZEQyxNQUE3RCxHQUFzRSxFQUF0RTtBQUNBLFNBQUtDLFFBQUwsQ0FBYyxZQUFVO0FBQ3BCLFdBQUtwQixJQUFMLENBQVVFLGNBQVYsQ0FBeUIsV0FBekIsRUFBc0NlLFlBQXRDLENBQW1EeEIsRUFBRSxDQUFDeUIsS0FBdEQsRUFBNkRDLE1BQTdELElBQXVFSixHQUFHLENBQUNDLENBQUQsQ0FBMUU7QUFDQUEsTUFBQUEsQ0FBQztBQUNKLEtBSEQsRUFHRyxHQUhILEVBR1FELEdBQUcsQ0FBQ00sTUFBSixHQUFXLENBSG5CLEVBR3NCLEdBSHRCO0FBSUgsR0EzR0k7QUE2R0xVLEVBQUFBLGVBQWUsRUFBQywyQkFBVTtBQUN0QixTQUFLL0IsSUFBTCxDQUFVRSxjQUFWLENBQXlCLFNBQXpCLEVBQW9DRCxNQUFwQyxHQUE2QyxLQUE3QztBQUNBLFNBQUtELElBQUwsQ0FBVUUsY0FBVixDQUF5QixTQUF6QixFQUFvQ0QsTUFBcEMsR0FBNkMsS0FBN0M7QUFDQSxTQUFLRCxJQUFMLENBQVVFLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NELE1BQXBDLEdBQTZDLEtBQTdDO0FBQ0EsU0FBS0QsSUFBTCxDQUFVQyxNQUFWLEdBQW1CLEtBQW5CO0FBQ0gsR0FsSEk7QUFvSEw7QUFHQStCLEVBQUFBLEtBdkhLLG1CQXVISSxDQUVSLENBekhJLENBMkhMOztBQTNISyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgVGV4dGluZGV4OmNjLkludGVnZXIsXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgdGhpcy5UZXh0aW5kZXggPSAwO1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJCdXR0b24xXCIpLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIkJ1dHRvbjJcIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiQnV0dG9uM1wiKS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vbigna2V5ZG93bicsdGhpcy5vbktleURvd24sdGhpcyk7Ly/nu5HlrprplK7nm5hcclxuICAgIH0sXHJcbiAgICBvbkRlc3Ryb3koKXtcclxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vZmYoJ2tleWRvd24nLHRoaXMub25LZXlEb3duLHRoaXMpO1xyXG4gICAgfSxcclxuICAgIG9uS2V5RG93bihlKXtcclxuICAgICAgICBzd2l0Y2goZS5rZXlDb2RlKXtcclxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuc3BhY2U6e1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jbG9zZVRleHQoKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIFxyXG5cclxuICAgIG9uX2J0bl9vbmNsaWNrX3Bob25lOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdmFyIHN0ciA9IFwi5oCO5LmI5piv5pif5pyf5YWr77yf5L+h5Y+35Lmf5rKh5LqG77yM56C05omL5py66IKv5a6a5piv5Z2P5LqG77yM6K+l5o2i5Y+w5paw55qE5LqG44CCXCI7XHJcbiAgICAgICAgdmFyIGogPSAwO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIlRleHRMYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJUZXh0TGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgKz0gc3RyW2pdO1xyXG4gICAgICAgICAgICBqKys7XHJcbiAgICAgICAgfSwgMC4xLCBzdHIubGVuZ3RoLTEsIDAuMik7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uX2J0bl9vbmNsaWNrX2xhcHRvcDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHZhciBzdHIgPSBcIuS9oOeahOeUteiEkeeDq+W+l+WKqOS4jeS6hu+8jOS8vOS5juWcqOi/kOihjOWkjeadgueahOeoi+W6j+OAglwiO1xyXG4gICAgICAgIHZhciBqID0gMDtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJUZXh0TGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiVGV4dExhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nICs9IHN0cltqXTtcclxuICAgICAgICAgICAgaisrO1xyXG4gICAgICAgIH0sIDAuMSwgc3RyLmxlbmd0aC0xLCAwLjIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbl9idG5fb25jbGlja19kb29yOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdmFyIHN0ciA9IFwi6Zeo6KKr6ZSB5LiK5LqG77yM6ZyA6KaB6ZKl5YyZ5omN6IO95omT5byA44CCXCI7XHJcbiAgICAgICAgdmFyIGogPSAwO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIlRleHRMYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCI7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJUZXh0TGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgKz0gc3RyW2pdO1xyXG4gICAgICAgICAgICBqKys7XHJcbiAgICAgICAgfSwgMC4xLCBzdHIubGVuZ3RoLTEsIDAuMik7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uX2J0bl9vbmNsaWNrX3dpbmRvdzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuVGV4dGluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB2YXIgc3RyID0gXCLnqpfmiLfljYrlvIDnnYDjgIJcIjtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJUZXh0TGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiVGV4dExhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nICs9IHN0clt0aGlzLlRleHRpbmRleF07XHJcbiAgICAgICAgICAgIHRoaXMuVGV4dGluZGV4Kys7XHJcbiAgICAgICAgfSwgMC4xLCBzdHIubGVuZ3RoLTEsIDAuMik7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uX2J0bl9vbmNsaWNrX2Rlc2s6ZnVuY3Rpb24oKXtcclxuICAgICAgICAvL+WcuuaZr+WIh+aNouWIsOWghuahjOWtkOWwj+a4uOaIj1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkdhbWVcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIGNsb3NlVGV4dCgpe1xyXG4gICAgICAgIGNjLmxvZyh0aGlzLlRleHRpbmRleCk7XHJcbiAgICAgICAgaWYodGhpcy5UZXh0aW5kZXggPT0gNil7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIkJ1dHRvbjFcIikuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiQnV0dG9uMlwiKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJCdXR0b24zXCIpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuVGV4dGluZGV4ID09IDAgKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLlRleHRpbmRleCA9IDA7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uY2xpY2tfQnV0dG9uMTpmdW5jdGlvbigpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIlNjZW5lIDIuMzFcIik7IC8v5Zy65pmv5YiH5o2i5YiwU2NlbmUyLjMxXHJcbiAgICAgICAgY2MubG9nKFwiY2hhbmdlIHRvIFNjZW5lIDIuMzFcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uY2xpY2tfQnV0dG9uMjpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIkJ1dHRvbjFcIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiQnV0dG9uMlwiKS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJCdXR0b24zXCIpLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHZhciBzdHIgPSBcIuayoeacieS6uuW6lOetlOOAglwiO1xyXG4gICAgICAgIHZhciBqID0gMDtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJUZXh0TGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiVGV4dExhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nICs9IHN0cltqXTtcclxuICAgICAgICAgICAgaisrO1xyXG4gICAgICAgIH0sIDAuMSwgc3RyLmxlbmd0aC0xLCAwLjIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbmNsaWNrX0J1dHRvbjM6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJCdXR0b24xXCIpLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIkJ1dHRvbjJcIikuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiQnV0dG9uM1wiKS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==