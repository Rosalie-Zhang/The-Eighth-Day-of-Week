
require('./assets/script/Choose1');
require('./assets/script/SearchScript');
require('./assets/script/Text2.2');
require('./assets/script/TextSwitch1.1');
require('./assets/script/TextSwitch1.21');
require('./assets/script/TextSwitch1.22');
require('./assets/script/TextSwitch1');
require('./assets/script/TextSwitch2.1');
require('./assets/script/TextSwitch2.31');
require('./assets/script/dizzySwitch');
require('./assets/script/globalVariable');
require('./assets/script/lookDiaryN');
require('./assets/script/lookDiaryO');
require('./assets/script/showConsciousNumber');
