
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Box.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ea81a0aVfNCnLHSfyLuV4bi', 'Box');
// scripts/Box.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.self = null; //自身刚体
        _this.self_box = null; //自身物理碰撞
        _this.self_collision = null; //自身碰撞
        _this.me = null; //自身
        _this.move = null; //箱子移动时的动画
        _this.isdown = false; //是否在向下降
        return _this;
    }
    NewClass.prototype.onLoad = function () {
        this.self.type = cc.RigidBodyType.Static; //开始时刚体是静止的
        this.move.play("move"); //播放移动动画
    };
    NewClass.prototype.update = function () {
        if (this.isdown == true) { //如果箱子正在下降
            this.self.type = cc.RigidBodyType.Dynamic; //刚体变成动态的
        }
    };
    __decorate([
        property(cc.RigidBody)
    ], NewClass.prototype, "self", void 0);
    __decorate([
        property(cc.PhysicsBoxCollider)
    ], NewClass.prototype, "self_box", void 0);
    __decorate([
        property(cc.BoxCollider)
    ], NewClass.prototype, "self_collision", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "me", void 0);
    __decorate([
        property(cc.Animation)
    ], NewClass.prototype, "move", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcQm94LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXNDLDRCQUFZO0lBQWxEO1FBQUEscUVBOEJDO1FBM0JHLFVBQUksR0FBZ0IsSUFBSSxDQUFDLENBQUEsTUFBTTtRQUcvQixjQUFRLEdBQXlCLElBQUksQ0FBQyxDQUFBLFFBQVE7UUFHOUMsb0JBQWMsR0FBa0IsSUFBSSxDQUFDLENBQUEsTUFBTTtRQUczQyxRQUFFLEdBQVcsSUFBSSxDQUFDLENBQUEsSUFBSTtRQUd0QixVQUFJLEdBQWdCLElBQUksQ0FBQyxDQUFBLFVBQVU7UUFFbkMsWUFBTSxHQUFXLEtBQUssQ0FBQyxDQUFBLFFBQVE7O0lBYW5DLENBQUM7SUFYRyx5QkFBTSxHQUFOO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQSxXQUFXO1FBQ3BELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUEsUUFBUTtJQUNuQyxDQUFDO0lBRUQseUJBQU0sR0FBTjtRQUNJLElBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUMsRUFBQyxVQUFVO1lBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUEsU0FBUztTQUN0RDtJQUNMLENBQUM7SUF6QkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQzswQ0FDRTtJQUd6QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsa0JBQWtCLENBQUM7OENBQ007SUFHdEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQztvREFDWTtJQUdyQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3dDQUNBO0lBR2xCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUM7MENBQ0U7SUFmUixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBOEI1QjtJQUFELGVBQUM7Q0E5QkQsQUE4QkMsQ0E5QnFDLEVBQUUsQ0FBQyxTQUFTLEdBOEJqRDtrQkE5Qm9CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ld0NsYXNzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuUmlnaWRCb2R5KVxyXG4gICAgc2VsZjpjYy5SaWdpZEJvZHkgPSBudWxsOy8v6Ieq6Lqr5Yia5L2TXHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlBoeXNpY3NCb3hDb2xsaWRlcilcclxuICAgIHNlbGZfYm94OmNjLlBoeXNpY3NCb3hDb2xsaWRlciA9IG51bGw7Ly/oh6rouqvniannkIbnorDmkp5cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuQm94Q29sbGlkZXIpXHJcbiAgICBzZWxmX2NvbGxpc2lvbjpjYy5Cb3hDb2xsaWRlciA9IG51bGw7Ly/oh6rouqvnorDmkp5cclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIG1lOmNjLk5vZGUgPSBudWxsOy8v6Ieq6LqrXHJcblxyXG4gICAgQHByb3BlcnR5KGNjLkFuaW1hdGlvbilcclxuICAgIG1vdmU6Y2MuQW5pbWF0aW9uID0gbnVsbDsvL+euseWtkOenu+WKqOaXtueahOWKqOeUu1xyXG5cclxuICAgIGlzZG93bjpib29sZWFuID0gZmFsc2U7Ly/mmK/lkKblnKjlkJHkuIvpmY1cclxuXHJcbiAgICBvbkxvYWQoKXtcclxuICAgICAgICB0aGlzLnNlbGYudHlwZSA9IGNjLlJpZ2lkQm9keVR5cGUuU3RhdGljOy8v5byA5aeL5pe25Yia5L2T5piv6Z2Z5q2i55qEXHJcbiAgICAgICAgdGhpcy5tb3ZlLnBsYXkoXCJtb3ZlXCIpOy8v5pKt5pS+56e75Yqo5Yqo55S7XHJcbiAgICB9XHJcblxyXG4gICAgdXBkYXRlKCl7XHJcbiAgICAgICAgaWYodGhpcy5pc2Rvd24gPT0gdHJ1ZSl7Ly/lpoLmnpznrrHlrZDmraPlnKjkuIvpmY1cclxuICAgICAgICAgICAgdGhpcy5zZWxmLnR5cGUgPSBjYy5SaWdpZEJvZHlUeXBlLkR5bmFtaWM7Ly/liJrkvZPlj5jmiJDliqjmgIHnmoRcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==