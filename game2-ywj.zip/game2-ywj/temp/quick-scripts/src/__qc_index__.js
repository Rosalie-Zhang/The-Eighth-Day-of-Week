
require('./assets/Script/Arrow');
require('./assets/Script/Back');
require('./assets/Script/Game');
require('./assets/Script/GameMgr');
require('./assets/Script/GameScore');
require('./assets/Script/Item');
