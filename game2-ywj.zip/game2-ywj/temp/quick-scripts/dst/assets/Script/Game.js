
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '54a06mhqCRC0ZsRL6jsaSE9', 'Game');
// Script/Game.js

"use strict";

// const score = require("GameScore");
cc.Class({
  "extends": cc.Component,
  properties: {
    arrowPrefab: {
      type: cc.Prefab,
      "default": null
    },
    targetPrefab: {
      type: cc.Prefab,
      "default": null
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.getPhysicsManager().enabled = true; //开启物理引擎

    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this); //触摸开始

    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this); //触摸移动

    this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this); //触摸结束，物体内部结束
  },
  start: function start() {
    this.createArrow();
    this.schedule(function () {
      this.createTarget();
    }, 2);
  },
  update: function update(dt) {},
  onTouchStart: function onTouchStart(event) {
    if (this.arrow) {
      this.arrow.updateArrowRotation(event.getLocation());
    }
  },
  onTouchMove: function onTouchMove(event) {
    if (this.arrow) {
      this.arrow.updateArrowRotation(event.getLocation());
    }
  },
  onTouchEnd: function onTouchEnd(event) {
    if (this.arrow) {
      this.arrow.shoot();
      this.arrow = null;
      this.scheduleOnce(function () {
        this.createArrow();
      }, 0.5);
    }
  },
  createArrow: function createArrow() {
    var arrowNode = cc.instantiate(this.arrowPrefab);
    arrowNode.x = -600;
    arrowNode.y = -240;
    arrowNode.zIndex = 1;
    arrowNode.parent = this.node;
    this.arrow = arrowNode.getComponent("Arrow");
  },
  createTarget: function createTarget() {
    var targetNode = cc.instantiate(this.targetPrefab);
    targetNode.x = this.randomInt(200, 750);
    targetNode.y = -700;
    targetNode.parent = this.node;
  },
  randomInt: function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYXJyb3dQcmVmYWIiLCJ0eXBlIiwiUHJlZmFiIiwidGFyZ2V0UHJlZmFiIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJnZXRQaHlzaWNzTWFuYWdlciIsImVuYWJsZWQiLCJub2RlIiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfU1RBUlQiLCJvblRvdWNoU3RhcnQiLCJUT1VDSF9NT1ZFIiwib25Ub3VjaE1vdmUiLCJUT1VDSF9FTkQiLCJvblRvdWNoRW5kIiwic3RhcnQiLCJjcmVhdGVBcnJvdyIsInNjaGVkdWxlIiwiY3JlYXRlVGFyZ2V0IiwidXBkYXRlIiwiZHQiLCJldmVudCIsImFycm93IiwidXBkYXRlQXJyb3dSb3RhdGlvbiIsImdldExvY2F0aW9uIiwic2hvb3QiLCJzY2hlZHVsZU9uY2UiLCJhcnJvd05vZGUiLCJpbnN0YW50aWF0ZSIsIngiLCJ5IiwiekluZGV4IiwicGFyZW50IiwiZ2V0Q29tcG9uZW50IiwidGFyZ2V0Tm9kZSIsInJhbmRvbUludCIsIm1pbiIsIm1heCIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsV0FBVyxFQUFFO0FBQ1RDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQURBO0FBRVQsaUJBQVM7QUFGQSxLQURMO0FBS1JDLElBQUFBLFlBQVksRUFBRTtBQUNWRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFEQztBQUVWLGlCQUFTO0FBRkM7QUFMTixHQUhQO0FBY0w7QUFFQUUsRUFBQUEsTUFoQkssb0JBZ0JLO0FBQ05SLElBQUFBLEVBQUUsQ0FBQ1MsUUFBSCxDQUFZQyxpQkFBWixHQUFnQ0MsT0FBaEMsR0FBMEMsSUFBMUMsQ0FETSxDQUN5Qzs7QUFDL0MsU0FBS0MsSUFBTCxDQUFVQyxFQUFWLENBQWFiLEVBQUUsQ0FBQ2MsSUFBSCxDQUFRQyxTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxLQUFLQyxZQUFqRCxFQUErRCxJQUEvRCxFQUZNLENBRStEOztBQUNyRSxTQUFLTCxJQUFMLENBQVVDLEVBQVYsQ0FBYWIsRUFBRSxDQUFDYyxJQUFILENBQVFDLFNBQVIsQ0FBa0JHLFVBQS9CLEVBQTJDLEtBQUtDLFdBQWhELEVBQTZELElBQTdELEVBSE0sQ0FHNkQ7O0FBQ25FLFNBQUtQLElBQUwsQ0FBVUMsRUFBVixDQUFhYixFQUFFLENBQUNjLElBQUgsQ0FBUUMsU0FBUixDQUFrQkssU0FBL0IsRUFBMEMsS0FBS0MsVUFBL0MsRUFBMkQsSUFBM0QsRUFKTSxDQUkyRDtBQUNwRSxHQXJCSTtBQXVCTEMsRUFBQUEsS0F2QkssbUJBdUJJO0FBQ0wsU0FBS0MsV0FBTDtBQUNBLFNBQUtDLFFBQUwsQ0FBYyxZQUFXO0FBQ3JCLFdBQUtDLFlBQUw7QUFDSCxLQUZELEVBRUcsQ0FGSDtBQUdILEdBNUJJO0FBOEJMQyxFQUFBQSxNQTlCSyxrQkE4QkdDLEVBOUJILEVBOEJPLENBRVgsQ0FoQ0k7QUFrQ0xWLEVBQUFBLFlBbENLLHdCQWtDU1csS0FsQ1QsRUFrQ2dCO0FBQ2pCLFFBQUksS0FBS0MsS0FBVCxFQUFnQjtBQUNaLFdBQUtBLEtBQUwsQ0FBV0MsbUJBQVgsQ0FBK0JGLEtBQUssQ0FBQ0csV0FBTixFQUEvQjtBQUNIO0FBQ0osR0F0Q0k7QUF3Q0xaLEVBQUFBLFdBeENLLHVCQXdDUVMsS0F4Q1IsRUF3Q2U7QUFDaEIsUUFBSSxLQUFLQyxLQUFULEVBQWdCO0FBQ1osV0FBS0EsS0FBTCxDQUFXQyxtQkFBWCxDQUErQkYsS0FBSyxDQUFDRyxXQUFOLEVBQS9CO0FBQ0g7QUFDSixHQTVDSTtBQThDTFYsRUFBQUEsVUE5Q0ssc0JBOENPTyxLQTlDUCxFQThDYztBQUNmLFFBQUksS0FBS0MsS0FBVCxFQUFnQjtBQUNaLFdBQUtBLEtBQUwsQ0FBV0csS0FBWDtBQUNBLFdBQUtILEtBQUwsR0FBYSxJQUFiO0FBQ0EsV0FBS0ksWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtWLFdBQUw7QUFDSCxPQUZELEVBRUcsR0FGSDtBQUdIO0FBQ0osR0F0REk7QUF3RExBLEVBQUFBLFdBeERLLHlCQXdEVTtBQUNYLFFBQUlXLFNBQVMsR0FBR2xDLEVBQUUsQ0FBQ21DLFdBQUgsQ0FBZSxLQUFLL0IsV0FBcEIsQ0FBaEI7QUFDQThCLElBQUFBLFNBQVMsQ0FBQ0UsQ0FBVixHQUFjLENBQUMsR0FBZjtBQUNBRixJQUFBQSxTQUFTLENBQUNHLENBQVYsR0FBYyxDQUFDLEdBQWY7QUFDQUgsSUFBQUEsU0FBUyxDQUFDSSxNQUFWLEdBQW1CLENBQW5CO0FBQ0FKLElBQUFBLFNBQVMsQ0FBQ0ssTUFBVixHQUFtQixLQUFLM0IsSUFBeEI7QUFDQSxTQUFLaUIsS0FBTCxHQUFhSyxTQUFTLENBQUNNLFlBQVYsQ0FBdUIsT0FBdkIsQ0FBYjtBQUNILEdBL0RJO0FBaUVMZixFQUFBQSxZQWpFSywwQkFpRVc7QUFDWixRQUFJZ0IsVUFBVSxHQUFHekMsRUFBRSxDQUFDbUMsV0FBSCxDQUFlLEtBQUs1QixZQUFwQixDQUFqQjtBQUNBa0MsSUFBQUEsVUFBVSxDQUFDTCxDQUFYLEdBQWUsS0FBS00sU0FBTCxDQUFlLEdBQWYsRUFBb0IsR0FBcEIsQ0FBZjtBQUNBRCxJQUFBQSxVQUFVLENBQUNKLENBQVgsR0FBZSxDQUFDLEdBQWhCO0FBQ0FJLElBQUFBLFVBQVUsQ0FBQ0YsTUFBWCxHQUFvQixLQUFLM0IsSUFBekI7QUFDSCxHQXRFSTtBQXdFTDhCLEVBQUFBLFNBeEVLLHFCQXdFTUMsR0F4RU4sRUF3RVdDLEdBeEVYLEVBd0VnQjtBQUNqQixXQUFPQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLE1BQWVILEdBQUcsR0FBR0QsR0FBTixHQUFZLENBQTNCLElBQWdDQSxHQUEzQyxDQUFQO0FBQ0g7QUExRUksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gY29uc3Qgc2NvcmUgPSByZXF1aXJlKFwiR2FtZVNjb3JlXCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGFycm93UHJlZmFiOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGFyZ2V0UHJlZmFiOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlOy8v5byA5ZCv54mp55CG5byV5pOOXHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLm9uVG91Y2hTdGFydCwgdGhpcyk7Ly/op6bmkbjlvIDlp4tcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5vblRvdWNoTW92ZSwgdGhpcyk7Ly/op6bmkbjnp7vliqhcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLm9uVG91Y2hFbmQsIHRoaXMpOy8v6Kem5pG457uT5p2f77yM54mp5L2T5YaF6YOo57uT5p2fXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLmNyZWF0ZUFycm93KCk7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgdGhpcy5jcmVhdGVUYXJnZXQoKTtcclxuICAgICAgICB9LCAyKTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlIChkdCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgb25Ub3VjaFN0YXJ0IChldmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLmFycm93KSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXJyb3cudXBkYXRlQXJyb3dSb3RhdGlvbihldmVudC5nZXRMb2NhdGlvbigpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uVG91Y2hNb3ZlIChldmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLmFycm93KSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXJyb3cudXBkYXRlQXJyb3dSb3RhdGlvbihldmVudC5nZXRMb2NhdGlvbigpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uVG91Y2hFbmQgKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKHRoaXMuYXJyb3cpIHtcclxuICAgICAgICAgICAgdGhpcy5hcnJvdy5zaG9vdCgpO1xyXG4gICAgICAgICAgICB0aGlzLmFycm93ID0gbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0ZUFycm93KCk7XHJcbiAgICAgICAgICAgIH0sIDAuNSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBjcmVhdGVBcnJvdyAoKSB7XHJcbiAgICAgICAgbGV0IGFycm93Tm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYXJyb3dQcmVmYWIpO1xyXG4gICAgICAgIGFycm93Tm9kZS54ID0gLTYwMDtcclxuICAgICAgICBhcnJvd05vZGUueSA9IC0yNDA7XHJcbiAgICAgICAgYXJyb3dOb2RlLnpJbmRleCA9IDE7XHJcbiAgICAgICAgYXJyb3dOb2RlLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICB0aGlzLmFycm93ID0gYXJyb3dOb2RlLmdldENvbXBvbmVudChcIkFycm93XCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBjcmVhdGVUYXJnZXQgKCkge1xyXG4gICAgICAgIGxldCB0YXJnZXROb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy50YXJnZXRQcmVmYWIpO1xyXG4gICAgICAgIHRhcmdldE5vZGUueCA9IHRoaXMucmFuZG9tSW50KDIwMCwgNzUwKTtcclxuICAgICAgICB0YXJnZXROb2RlLnkgPSAtNzAwO1xyXG4gICAgICAgIHRhcmdldE5vZGUucGFyZW50ID0gdGhpcy5ub2RlO1xyXG4gICAgfSxcclxuXHJcbiAgICByYW5kb21JbnQgKG1pbiwgbWF4KSB7XHJcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSoobWF4IC0gbWluICsgMSkgKyBtaW4pO1xyXG4gICAgfVxyXG59KTtcclxuIl19