
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameScore.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e37c18Ant5D0rKmuJuKPg8/', 'GameScore');
// Script/GameScore.js

"use strict";

// let scoreInfo = {
//     time : 30,
//     hitscore : 0,
//     scoreAdd : function(k){
//         this.hitscore +=k;
//     },
// };
module.exports = {
  time: 60,
  hitscore: 0,
  scoreAdd: function scoreAdd(k) {
    this.hitscore += k;
  }
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lU2NvcmUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsInRpbWUiLCJoaXRzY29yZSIsInNjb3JlQWRkIiwiayJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDYkMsRUFBQUEsSUFBSSxFQUFHLEVBRE07QUFFYkMsRUFBQUEsUUFBUSxFQUFHLENBRkU7QUFHYkMsRUFBQUEsUUFBUSxFQUFHLGtCQUFTQyxDQUFULEVBQVc7QUFDbEIsU0FBS0YsUUFBTCxJQUFlRSxDQUFmO0FBQ0g7QUFMWSxDQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gbGV0IHNjb3JlSW5mbyA9IHtcclxuLy8gICAgIHRpbWUgOiAzMCxcclxuLy8gICAgIGhpdHNjb3JlIDogMCxcclxuLy8gICAgIHNjb3JlQWRkIDogZnVuY3Rpb24oayl7XHJcbi8vICAgICAgICAgdGhpcy5oaXRzY29yZSArPWs7XHJcbi8vICAgICB9LFxyXG4vLyB9O1xyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICAgIHRpbWUgOiA2MCxcclxuICAgIGhpdHNjb3JlIDogMCxcclxuICAgIHNjb3JlQWRkIDogZnVuY3Rpb24oayl7XHJcbiAgICAgICAgdGhpcy5oaXRzY29yZSs9aztcclxuICAgIH1cclxufTtcclxuIl19