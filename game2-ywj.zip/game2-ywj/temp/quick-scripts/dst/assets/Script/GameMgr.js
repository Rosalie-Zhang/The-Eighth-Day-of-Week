
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fbeb7RnNFJEkZxVZSsHgJ0X', 'GameMgr');
// Script/GameMgr.js

"use strict";

// import { hitscore } from "GameScore";
var score = require("GameScore");

cc.Class({
  "extends": cc.Component,
  properties: {
    score: {
      type: cc.Label,
      "default": null,
      tooltip: "得分显示Label组件"
    },
    timeBar: {
      type: cc.ProgressBar,
      "default": null,
      tooltip: "时间进度条"
    },
    losesound: {
      type: cc.AudioClip,
      "default": null
    },
    winsound: {
      type: cc.AudioClip,
      "default": null
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var limitTime = score.time; //游戏限时总时间

    this.schedule(function () {
      if (score.time > 0) {
        score.time--; //倒计时

        this.timeBar.progress = score.time / limitTime;
      } else {
        if (score.hitscore >= 30) {
          // this.winsound.play();
          cc.audioEngine.play(this.winsound);
          cc.director.loadScene("Win");
        } else {
          // this.losesound.play();
          cc.audioEngine.play(this.losesound);
          cc.director.loadScene("Lose");
        }
      }
    }, 1);
  },
  start: function start() {},
  update: function update(dt) {
    this.score.string = score.hitscore; //加分
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lTWdyLmpzIl0sIm5hbWVzIjpbInNjb3JlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwidHlwZSIsIkxhYmVsIiwidG9vbHRpcCIsInRpbWVCYXIiLCJQcm9ncmVzc0JhciIsImxvc2Vzb3VuZCIsIkF1ZGlvQ2xpcCIsIndpbnNvdW5kIiwib25Mb2FkIiwibGltaXRUaW1lIiwidGltZSIsInNjaGVkdWxlIiwicHJvZ3Jlc3MiLCJoaXRzY29yZSIsImF1ZGlvRW5naW5lIiwicGxheSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsInN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLEtBQUssR0FBR0MsT0FBTyxDQUFDLFdBQUQsQ0FBbkI7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSTCxJQUFBQSxLQUFLLEVBQUc7QUFDSk0sTUFBQUEsSUFBSSxFQUFDSixFQUFFLENBQUNLLEtBREo7QUFFSixpQkFBUSxJQUZKO0FBR0pDLE1BQUFBLE9BQU8sRUFBQztBQUhKLEtBREE7QUFNUkMsSUFBQUEsT0FBTyxFQUFHO0FBQ05ILE1BQUFBLElBQUksRUFBQ0osRUFBRSxDQUFDUSxXQURGO0FBRU4saUJBQVEsSUFGRjtBQUdORixNQUFBQSxPQUFPLEVBQUM7QUFIRixLQU5GO0FBV1JHLElBQUFBLFNBQVMsRUFBRztBQUNSTCxNQUFBQSxJQUFJLEVBQUdKLEVBQUUsQ0FBQ1UsU0FERjtBQUVSLGlCQUFVO0FBRkYsS0FYSjtBQWVSQyxJQUFBQSxRQUFRLEVBQUc7QUFDUFAsTUFBQUEsSUFBSSxFQUFHSixFQUFFLENBQUNVLFNBREg7QUFFUCxpQkFBVTtBQUZIO0FBZkgsR0FIUDtBQXdCTDtBQUVBRSxFQUFBQSxNQTFCSyxvQkEwQks7QUFDTixRQUFJQyxTQUFTLEdBQUdmLEtBQUssQ0FBQ2dCLElBQXRCLENBRE0sQ0FDcUI7O0FBQzNCLFNBQUtDLFFBQUwsQ0FBYyxZQUFVO0FBQ3BCLFVBQUdqQixLQUFLLENBQUNnQixJQUFOLEdBQWEsQ0FBaEIsRUFBa0I7QUFDZGhCLFFBQUFBLEtBQUssQ0FBQ2dCLElBQU4sR0FEYyxDQUNEOztBQUNiLGFBQUtQLE9BQUwsQ0FBYVMsUUFBYixHQUF3QmxCLEtBQUssQ0FBQ2dCLElBQU4sR0FBYUQsU0FBckM7QUFDSCxPQUhELE1BR0s7QUFDRCxZQUFHZixLQUFLLENBQUNtQixRQUFOLElBQWlCLEVBQXBCLEVBQXVCO0FBQ25CO0FBQ0FqQixVQUFBQSxFQUFFLENBQUNrQixXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS1IsUUFBekI7QUFDQVgsVUFBQUEsRUFBRSxDQUFDb0IsUUFBSCxDQUFZQyxTQUFaLENBQXNCLEtBQXRCO0FBQ0gsU0FKRCxNQUlLO0FBQ0Q7QUFDQXJCLFVBQUFBLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLVixTQUF6QjtBQUNBVCxVQUFBQSxFQUFFLENBQUNvQixRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSDtBQUNKO0FBQ0osS0FmRCxFQWVFLENBZkY7QUFnQkgsR0E1Q0k7QUE4Q0xDLEVBQUFBLEtBOUNLLG1CQThDSSxDQUVSLENBaERJO0FBa0RMQyxFQUFBQSxNQWxESyxrQkFrREdDLEVBbERILEVBa0RPO0FBQ1IsU0FBSzFCLEtBQUwsQ0FBVzJCLE1BQVgsR0FBb0IzQixLQUFLLENBQUNtQixRQUExQixDQURRLENBQzJCO0FBQ3RDO0FBcERJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCB7IGhpdHNjb3JlIH0gZnJvbSBcIkdhbWVTY29yZVwiO1xyXG52YXIgc2NvcmUgPSByZXF1aXJlKFwiR2FtZVNjb3JlXCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHNjb3JlIDoge1xyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHRvb2x0aXA6XCLlvpfliIbmmL7npLpMYWJlbOe7hOS7tlwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGltZUJhciA6IHtcclxuICAgICAgICAgICAgdHlwZTpjYy5Qcm9ncmVzc0JhcixcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0b29sdGlwOlwi5pe26Ze06L+b5bqm5p2hXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBsb3Nlc291bmQgOiB7XHJcbiAgICAgICAgICAgIHR5cGUgOiBjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB3aW5zb3VuZCA6IHtcclxuICAgICAgICAgICAgdHlwZSA6IGNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgbGV0IGxpbWl0VGltZSA9IHNjb3JlLnRpbWU7Ly/muLjmiI/pmZDml7bmgLvml7bpl7RcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGlmKHNjb3JlLnRpbWUgPiAwKXtcclxuICAgICAgICAgICAgICAgIHNjb3JlLnRpbWUtLTsvL+WAkuiuoeaXtlxyXG4gICAgICAgICAgICAgICAgdGhpcy50aW1lQmFyLnByb2dyZXNzID0gc2NvcmUudGltZSAvIGxpbWl0VGltZTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBpZihzY29yZS5oaXRzY29yZSA+PTMwKXsgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMud2luc291bmQucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy53aW5zb3VuZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiV2luXCIpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5sb3Nlc291bmQucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5sb3Nlc291bmQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkxvc2VcIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LDEpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdGhpcy5zY29yZS5zdHJpbmcgPSBzY29yZS5oaXRzY29yZTsvL+WKoOWIhlxyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==