
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Arrow');
require('./assets/Script/Back');
require('./assets/Script/Game');
require('./assets/Script/GameMgr');
require('./assets/Script/GameScore');
require('./assets/Script/Item');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Back.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4bb6ah5jlVNTpZPVSGED9qz', 'Back');
// Script/Back.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  toGamey: function toGamey() {
    cc.director.loadScene("Gamey");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxCYWNrLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJ0b0dhbWV5IiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxDQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZRLEdBSFA7QUFxQkw7QUFFQTtBQUVBQyxFQUFBQSxLQXpCSyxtQkF5QkksQ0FFUixDQTNCSTtBQTZCTEMsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2RMLElBQUFBLEVBQUUsQ0FBQ00sUUFBSCxDQUFZQyxTQUFaLENBQXNCLE9BQXRCO0FBQ0gsR0EvQkksQ0FpQ0w7O0FBakNLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICB0b0dhbWV5OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZXlcIilcclxuICAgIH1cclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fbeb7RnNFJEkZxVZSsHgJ0X', 'GameMgr');
// Script/GameMgr.js

"use strict";

// import { hitscore } from "GameScore";
var score = require("GameScore");

cc.Class({
  "extends": cc.Component,
  properties: {
    score: {
      type: cc.Label,
      "default": null,
      tooltip: "得分显示Label组件"
    },
    timeBar: {
      type: cc.ProgressBar,
      "default": null,
      tooltip: "时间进度条"
    },
    losesound: {
      type: cc.AudioClip,
      "default": null
    },
    winsound: {
      type: cc.AudioClip,
      "default": null
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var limitTime = score.time; //游戏限时总时间

    this.schedule(function () {
      if (score.time > 0) {
        score.time--; //倒计时

        this.timeBar.progress = score.time / limitTime;
      } else {
        if (score.hitscore >= 30) {
          // this.winsound.play();
          cc.audioEngine.play(this.winsound);
          cc.director.loadScene("Win");
        } else {
          // this.losesound.play();
          cc.audioEngine.play(this.losesound);
          cc.director.loadScene("Lose");
        }
      }
    }, 1);
  },
  start: function start() {},
  update: function update(dt) {
    this.score.string = score.hitscore; //加分
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lTWdyLmpzIl0sIm5hbWVzIjpbInNjb3JlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwidHlwZSIsIkxhYmVsIiwidG9vbHRpcCIsInRpbWVCYXIiLCJQcm9ncmVzc0JhciIsImxvc2Vzb3VuZCIsIkF1ZGlvQ2xpcCIsIndpbnNvdW5kIiwib25Mb2FkIiwibGltaXRUaW1lIiwidGltZSIsInNjaGVkdWxlIiwicHJvZ3Jlc3MiLCJoaXRzY29yZSIsImF1ZGlvRW5naW5lIiwicGxheSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsInN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLEtBQUssR0FBR0MsT0FBTyxDQUFDLFdBQUQsQ0FBbkI7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSTCxJQUFBQSxLQUFLLEVBQUc7QUFDSk0sTUFBQUEsSUFBSSxFQUFDSixFQUFFLENBQUNLLEtBREo7QUFFSixpQkFBUSxJQUZKO0FBR0pDLE1BQUFBLE9BQU8sRUFBQztBQUhKLEtBREE7QUFNUkMsSUFBQUEsT0FBTyxFQUFHO0FBQ05ILE1BQUFBLElBQUksRUFBQ0osRUFBRSxDQUFDUSxXQURGO0FBRU4saUJBQVEsSUFGRjtBQUdORixNQUFBQSxPQUFPLEVBQUM7QUFIRixLQU5GO0FBV1JHLElBQUFBLFNBQVMsRUFBRztBQUNSTCxNQUFBQSxJQUFJLEVBQUdKLEVBQUUsQ0FBQ1UsU0FERjtBQUVSLGlCQUFVO0FBRkYsS0FYSjtBQWVSQyxJQUFBQSxRQUFRLEVBQUc7QUFDUFAsTUFBQUEsSUFBSSxFQUFHSixFQUFFLENBQUNVLFNBREg7QUFFUCxpQkFBVTtBQUZIO0FBZkgsR0FIUDtBQXdCTDtBQUVBRSxFQUFBQSxNQTFCSyxvQkEwQks7QUFDTixRQUFJQyxTQUFTLEdBQUdmLEtBQUssQ0FBQ2dCLElBQXRCLENBRE0sQ0FDcUI7O0FBQzNCLFNBQUtDLFFBQUwsQ0FBYyxZQUFVO0FBQ3BCLFVBQUdqQixLQUFLLENBQUNnQixJQUFOLEdBQWEsQ0FBaEIsRUFBa0I7QUFDZGhCLFFBQUFBLEtBQUssQ0FBQ2dCLElBQU4sR0FEYyxDQUNEOztBQUNiLGFBQUtQLE9BQUwsQ0FBYVMsUUFBYixHQUF3QmxCLEtBQUssQ0FBQ2dCLElBQU4sR0FBYUQsU0FBckM7QUFDSCxPQUhELE1BR0s7QUFDRCxZQUFHZixLQUFLLENBQUNtQixRQUFOLElBQWlCLEVBQXBCLEVBQXVCO0FBQ25CO0FBQ0FqQixVQUFBQSxFQUFFLENBQUNrQixXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS1IsUUFBekI7QUFDQVgsVUFBQUEsRUFBRSxDQUFDb0IsUUFBSCxDQUFZQyxTQUFaLENBQXNCLEtBQXRCO0FBQ0gsU0FKRCxNQUlLO0FBQ0Q7QUFDQXJCLFVBQUFBLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLVixTQUF6QjtBQUNBVCxVQUFBQSxFQUFFLENBQUNvQixRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSDtBQUNKO0FBQ0osS0FmRCxFQWVFLENBZkY7QUFnQkgsR0E1Q0k7QUE4Q0xDLEVBQUFBLEtBOUNLLG1CQThDSSxDQUVSLENBaERJO0FBa0RMQyxFQUFBQSxNQWxESyxrQkFrREdDLEVBbERILEVBa0RPO0FBQ1IsU0FBSzFCLEtBQUwsQ0FBVzJCLE1BQVgsR0FBb0IzQixLQUFLLENBQUNtQixRQUExQixDQURRLENBQzJCO0FBQ3RDO0FBcERJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCB7IGhpdHNjb3JlIH0gZnJvbSBcIkdhbWVTY29yZVwiO1xyXG52YXIgc2NvcmUgPSByZXF1aXJlKFwiR2FtZVNjb3JlXCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHNjb3JlIDoge1xyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHRvb2x0aXA6XCLlvpfliIbmmL7npLpMYWJlbOe7hOS7tlwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGltZUJhciA6IHtcclxuICAgICAgICAgICAgdHlwZTpjYy5Qcm9ncmVzc0JhcixcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0b29sdGlwOlwi5pe26Ze06L+b5bqm5p2hXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBsb3Nlc291bmQgOiB7XHJcbiAgICAgICAgICAgIHR5cGUgOiBjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB3aW5zb3VuZCA6IHtcclxuICAgICAgICAgICAgdHlwZSA6IGNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgbGV0IGxpbWl0VGltZSA9IHNjb3JlLnRpbWU7Ly/muLjmiI/pmZDml7bmgLvml7bpl7RcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGlmKHNjb3JlLnRpbWUgPiAwKXtcclxuICAgICAgICAgICAgICAgIHNjb3JlLnRpbWUtLTsvL+WAkuiuoeaXtlxyXG4gICAgICAgICAgICAgICAgdGhpcy50aW1lQmFyLnByb2dyZXNzID0gc2NvcmUudGltZSAvIGxpbWl0VGltZTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBpZihzY29yZS5oaXRzY29yZSA+PTMwKXsgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMud2luc291bmQucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy53aW5zb3VuZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiV2luXCIpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5sb3Nlc291bmQucGxheSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5sb3Nlc291bmQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkxvc2VcIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LDEpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdGhpcy5zY29yZS5zdHJpbmcgPSBzY29yZS5oaXRzY29yZTsvL+WKoOWIhlxyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameScore.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e37c18Ant5D0rKmuJuKPg8/', 'GameScore');
// Script/GameScore.js

"use strict";

// let scoreInfo = {
//     time : 30,
//     hitscore : 0,
//     scoreAdd : function(k){
//         this.hitscore +=k;
//     },
// };
module.exports = {
  time: 60,
  hitscore: 0,
  scoreAdd: function scoreAdd(k) {
    this.hitscore += k;
  }
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lU2NvcmUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsInRpbWUiLCJoaXRzY29yZSIsInNjb3JlQWRkIiwiayJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDYkMsRUFBQUEsSUFBSSxFQUFHLEVBRE07QUFFYkMsRUFBQUEsUUFBUSxFQUFHLENBRkU7QUFHYkMsRUFBQUEsUUFBUSxFQUFHLGtCQUFTQyxDQUFULEVBQVc7QUFDbEIsU0FBS0YsUUFBTCxJQUFlRSxDQUFmO0FBQ0g7QUFMWSxDQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gbGV0IHNjb3JlSW5mbyA9IHtcclxuLy8gICAgIHRpbWUgOiAzMCxcclxuLy8gICAgIGhpdHNjb3JlIDogMCxcclxuLy8gICAgIHNjb3JlQWRkIDogZnVuY3Rpb24oayl7XHJcbi8vICAgICAgICAgdGhpcy5oaXRzY29yZSArPWs7XHJcbi8vICAgICB9LFxyXG4vLyB9O1xyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICAgIHRpbWUgOiA2MCxcclxuICAgIGhpdHNjb3JlIDogMCxcclxuICAgIHNjb3JlQWRkIDogZnVuY3Rpb24oayl7XHJcbiAgICAgICAgdGhpcy5oaXRzY29yZSs9aztcclxuICAgIH1cclxufTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '54a06mhqCRC0ZsRL6jsaSE9', 'Game');
// Script/Game.js

"use strict";

// const score = require("GameScore");
cc.Class({
  "extends": cc.Component,
  properties: {
    arrowPrefab: {
      type: cc.Prefab,
      "default": null
    },
    targetPrefab: {
      type: cc.Prefab,
      "default": null
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.getPhysicsManager().enabled = true; //开启物理引擎

    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this); //触摸开始

    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this); //触摸移动

    this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this); //触摸结束，物体内部结束
  },
  start: function start() {
    this.createArrow();
    this.schedule(function () {
      this.createTarget();
    }, 2);
  },
  update: function update(dt) {},
  onTouchStart: function onTouchStart(event) {
    if (this.arrow) {
      this.arrow.updateArrowRotation(event.getLocation());
    }
  },
  onTouchMove: function onTouchMove(event) {
    if (this.arrow) {
      this.arrow.updateArrowRotation(event.getLocation());
    }
  },
  onTouchEnd: function onTouchEnd(event) {
    if (this.arrow) {
      this.arrow.shoot();
      this.arrow = null;
      this.scheduleOnce(function () {
        this.createArrow();
      }, 0.5);
    }
  },
  createArrow: function createArrow() {
    var arrowNode = cc.instantiate(this.arrowPrefab);
    arrowNode.x = -600;
    arrowNode.y = -240;
    arrowNode.zIndex = 1;
    arrowNode.parent = this.node;
    this.arrow = arrowNode.getComponent("Arrow");
  },
  createTarget: function createTarget() {
    var targetNode = cc.instantiate(this.targetPrefab);
    targetNode.x = this.randomInt(200, 750);
    targetNode.y = -700;
    targetNode.parent = this.node;
  },
  randomInt: function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYXJyb3dQcmVmYWIiLCJ0eXBlIiwiUHJlZmFiIiwidGFyZ2V0UHJlZmFiIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJnZXRQaHlzaWNzTWFuYWdlciIsImVuYWJsZWQiLCJub2RlIiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfU1RBUlQiLCJvblRvdWNoU3RhcnQiLCJUT1VDSF9NT1ZFIiwib25Ub3VjaE1vdmUiLCJUT1VDSF9FTkQiLCJvblRvdWNoRW5kIiwic3RhcnQiLCJjcmVhdGVBcnJvdyIsInNjaGVkdWxlIiwiY3JlYXRlVGFyZ2V0IiwidXBkYXRlIiwiZHQiLCJldmVudCIsImFycm93IiwidXBkYXRlQXJyb3dSb3RhdGlvbiIsImdldExvY2F0aW9uIiwic2hvb3QiLCJzY2hlZHVsZU9uY2UiLCJhcnJvd05vZGUiLCJpbnN0YW50aWF0ZSIsIngiLCJ5IiwiekluZGV4IiwicGFyZW50IiwiZ2V0Q29tcG9uZW50IiwidGFyZ2V0Tm9kZSIsInJhbmRvbUludCIsIm1pbiIsIm1heCIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsV0FBVyxFQUFFO0FBQ1RDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQURBO0FBRVQsaUJBQVM7QUFGQSxLQURMO0FBS1JDLElBQUFBLFlBQVksRUFBRTtBQUNWRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFEQztBQUVWLGlCQUFTO0FBRkM7QUFMTixHQUhQO0FBY0w7QUFFQUUsRUFBQUEsTUFoQkssb0JBZ0JLO0FBQ05SLElBQUFBLEVBQUUsQ0FBQ1MsUUFBSCxDQUFZQyxpQkFBWixHQUFnQ0MsT0FBaEMsR0FBMEMsSUFBMUMsQ0FETSxDQUN5Qzs7QUFDL0MsU0FBS0MsSUFBTCxDQUFVQyxFQUFWLENBQWFiLEVBQUUsQ0FBQ2MsSUFBSCxDQUFRQyxTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxLQUFLQyxZQUFqRCxFQUErRCxJQUEvRCxFQUZNLENBRStEOztBQUNyRSxTQUFLTCxJQUFMLENBQVVDLEVBQVYsQ0FBYWIsRUFBRSxDQUFDYyxJQUFILENBQVFDLFNBQVIsQ0FBa0JHLFVBQS9CLEVBQTJDLEtBQUtDLFdBQWhELEVBQTZELElBQTdELEVBSE0sQ0FHNkQ7O0FBQ25FLFNBQUtQLElBQUwsQ0FBVUMsRUFBVixDQUFhYixFQUFFLENBQUNjLElBQUgsQ0FBUUMsU0FBUixDQUFrQkssU0FBL0IsRUFBMEMsS0FBS0MsVUFBL0MsRUFBMkQsSUFBM0QsRUFKTSxDQUkyRDtBQUNwRSxHQXJCSTtBQXVCTEMsRUFBQUEsS0F2QkssbUJBdUJJO0FBQ0wsU0FBS0MsV0FBTDtBQUNBLFNBQUtDLFFBQUwsQ0FBYyxZQUFXO0FBQ3JCLFdBQUtDLFlBQUw7QUFDSCxLQUZELEVBRUcsQ0FGSDtBQUdILEdBNUJJO0FBOEJMQyxFQUFBQSxNQTlCSyxrQkE4QkdDLEVBOUJILEVBOEJPLENBRVgsQ0FoQ0k7QUFrQ0xWLEVBQUFBLFlBbENLLHdCQWtDU1csS0FsQ1QsRUFrQ2dCO0FBQ2pCLFFBQUksS0FBS0MsS0FBVCxFQUFnQjtBQUNaLFdBQUtBLEtBQUwsQ0FBV0MsbUJBQVgsQ0FBK0JGLEtBQUssQ0FBQ0csV0FBTixFQUEvQjtBQUNIO0FBQ0osR0F0Q0k7QUF3Q0xaLEVBQUFBLFdBeENLLHVCQXdDUVMsS0F4Q1IsRUF3Q2U7QUFDaEIsUUFBSSxLQUFLQyxLQUFULEVBQWdCO0FBQ1osV0FBS0EsS0FBTCxDQUFXQyxtQkFBWCxDQUErQkYsS0FBSyxDQUFDRyxXQUFOLEVBQS9CO0FBQ0g7QUFDSixHQTVDSTtBQThDTFYsRUFBQUEsVUE5Q0ssc0JBOENPTyxLQTlDUCxFQThDYztBQUNmLFFBQUksS0FBS0MsS0FBVCxFQUFnQjtBQUNaLFdBQUtBLEtBQUwsQ0FBV0csS0FBWDtBQUNBLFdBQUtILEtBQUwsR0FBYSxJQUFiO0FBQ0EsV0FBS0ksWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtWLFdBQUw7QUFDSCxPQUZELEVBRUcsR0FGSDtBQUdIO0FBQ0osR0F0REk7QUF3RExBLEVBQUFBLFdBeERLLHlCQXdEVTtBQUNYLFFBQUlXLFNBQVMsR0FBR2xDLEVBQUUsQ0FBQ21DLFdBQUgsQ0FBZSxLQUFLL0IsV0FBcEIsQ0FBaEI7QUFDQThCLElBQUFBLFNBQVMsQ0FBQ0UsQ0FBVixHQUFjLENBQUMsR0FBZjtBQUNBRixJQUFBQSxTQUFTLENBQUNHLENBQVYsR0FBYyxDQUFDLEdBQWY7QUFDQUgsSUFBQUEsU0FBUyxDQUFDSSxNQUFWLEdBQW1CLENBQW5CO0FBQ0FKLElBQUFBLFNBQVMsQ0FBQ0ssTUFBVixHQUFtQixLQUFLM0IsSUFBeEI7QUFDQSxTQUFLaUIsS0FBTCxHQUFhSyxTQUFTLENBQUNNLFlBQVYsQ0FBdUIsT0FBdkIsQ0FBYjtBQUNILEdBL0RJO0FBaUVMZixFQUFBQSxZQWpFSywwQkFpRVc7QUFDWixRQUFJZ0IsVUFBVSxHQUFHekMsRUFBRSxDQUFDbUMsV0FBSCxDQUFlLEtBQUs1QixZQUFwQixDQUFqQjtBQUNBa0MsSUFBQUEsVUFBVSxDQUFDTCxDQUFYLEdBQWUsS0FBS00sU0FBTCxDQUFlLEdBQWYsRUFBb0IsR0FBcEIsQ0FBZjtBQUNBRCxJQUFBQSxVQUFVLENBQUNKLENBQVgsR0FBZSxDQUFDLEdBQWhCO0FBQ0FJLElBQUFBLFVBQVUsQ0FBQ0YsTUFBWCxHQUFvQixLQUFLM0IsSUFBekI7QUFDSCxHQXRFSTtBQXdFTDhCLEVBQUFBLFNBeEVLLHFCQXdFTUMsR0F4RU4sRUF3RVdDLEdBeEVYLEVBd0VnQjtBQUNqQixXQUFPQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLE1BQWVILEdBQUcsR0FBR0QsR0FBTixHQUFZLENBQTNCLElBQWdDQSxHQUEzQyxDQUFQO0FBQ0g7QUExRUksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gY29uc3Qgc2NvcmUgPSByZXF1aXJlKFwiR2FtZVNjb3JlXCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGFycm93UHJlZmFiOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGFyZ2V0UHJlZmFiOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlOy8v5byA5ZCv54mp55CG5byV5pOOXHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLm9uVG91Y2hTdGFydCwgdGhpcyk7Ly/op6bmkbjlvIDlp4tcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5vblRvdWNoTW92ZSwgdGhpcyk7Ly/op6bmkbjnp7vliqhcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLm9uVG91Y2hFbmQsIHRoaXMpOy8v6Kem5pG457uT5p2f77yM54mp5L2T5YaF6YOo57uT5p2fXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLmNyZWF0ZUFycm93KCk7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgdGhpcy5jcmVhdGVUYXJnZXQoKTtcclxuICAgICAgICB9LCAyKTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlIChkdCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgb25Ub3VjaFN0YXJ0IChldmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLmFycm93KSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXJyb3cudXBkYXRlQXJyb3dSb3RhdGlvbihldmVudC5nZXRMb2NhdGlvbigpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uVG91Y2hNb3ZlIChldmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLmFycm93KSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXJyb3cudXBkYXRlQXJyb3dSb3RhdGlvbihldmVudC5nZXRMb2NhdGlvbigpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uVG91Y2hFbmQgKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKHRoaXMuYXJyb3cpIHtcclxuICAgICAgICAgICAgdGhpcy5hcnJvdy5zaG9vdCgpO1xyXG4gICAgICAgICAgICB0aGlzLmFycm93ID0gbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0ZUFycm93KCk7XHJcbiAgICAgICAgICAgIH0sIDAuNSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBjcmVhdGVBcnJvdyAoKSB7XHJcbiAgICAgICAgbGV0IGFycm93Tm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYXJyb3dQcmVmYWIpO1xyXG4gICAgICAgIGFycm93Tm9kZS54ID0gLTYwMDtcclxuICAgICAgICBhcnJvd05vZGUueSA9IC0yNDA7XHJcbiAgICAgICAgYXJyb3dOb2RlLnpJbmRleCA9IDE7XHJcbiAgICAgICAgYXJyb3dOb2RlLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICB0aGlzLmFycm93ID0gYXJyb3dOb2RlLmdldENvbXBvbmVudChcIkFycm93XCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBjcmVhdGVUYXJnZXQgKCkge1xyXG4gICAgICAgIGxldCB0YXJnZXROb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy50YXJnZXRQcmVmYWIpO1xyXG4gICAgICAgIHRhcmdldE5vZGUueCA9IHRoaXMucmFuZG9tSW50KDIwMCwgNzUwKTtcclxuICAgICAgICB0YXJnZXROb2RlLnkgPSAtNzAwO1xyXG4gICAgICAgIHRhcmdldE5vZGUucGFyZW50ID0gdGhpcy5ub2RlO1xyXG4gICAgfSxcclxuXHJcbiAgICByYW5kb21JbnQgKG1pbiwgbWF4KSB7XHJcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSoobWF4IC0gbWluICsgMSkgKyBtaW4pO1xyXG4gICAgfVxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Item.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '71e08U3p1tKXpKL9dPSFhDZ', 'Item');
// Script/Item.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this.node.y < -cc.winSize.height / 2 - 200) {
      this.node.destroy();
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxJdGVtLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm5vZGUiLCJ5Iiwid2luU2l6ZSIsImhlaWdodCIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBTUw7QUFFQTtBQUVBQyxFQUFBQSxLQVZLLG1CQVVJLENBRVIsQ0FaSTtBQWNMQyxFQUFBQSxNQWRLLGtCQWNHQyxFQWRILEVBY087QUFDUixRQUFJLEtBQUtDLElBQUwsQ0FBVUMsQ0FBVixHQUFjLENBQUNSLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXQyxNQUFaLEdBQW1CLENBQW5CLEdBQXVCLEdBQXpDLEVBQThDO0FBQzFDLFdBQUtILElBQUwsQ0FBVUksT0FBVjtBQUNIO0FBQ0o7QUFsQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPCAtY2Mud2luU2l6ZS5oZWlnaHQvMiAtIDIwMCkge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZGVzdHJveSgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Arrow.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3543anw16VCH7P+izHmvwhY', 'Arrow');
// Script/Arrow.js

"use strict";

var score = require('GameScore');

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.direction = cc.v2(0, 0);
    this.rigidBody = this.getComponent(cc.RigidBody);
    this.weldJoint = this.getComponent(cc.WeldJoint);
  },
  start: function start() {},
  update: function update(dt) {
    var velocity = this.rigidBody.linearVelocity;
    var speed = velocity.mag();
    if (speed === 0) return;
    var angle = velocity.signAngle(cc.v2(1, 0));
    this.node.angle = -(angle * 180 / Math.PI);
    var dragConstant = 0.1;
    var direction = velocity.normalize();
    var pointingDirection = this.rigidBody.getWorldVector(cc.v2(1, 0));
    var flightDirection = this.rigidBody.linearVelocity;
    var flightSpeed = flightDirection.mag();
    flightDirection.normalizeSelf();
    var dot = flightDirection.dot(pointingDirection);
    var dragForceMagnitude = (1 - Math.abs(dot)) * flightSpeed * flightSpeed * dragConstant * this.rigidBody.getMass();
    var arrowTailPosition = this.rigidBody.getWorldPoint(cc.v2(-68, 0));
    this.rigidBody.applyForce(flightDirection.mul(-dragForceMagnitude), arrowTailPosition, false);
  },
  updateArrowRotation: function updateArrowRotation(pos) {
    pos = this.node.parent.convertToNodeSpaceAR(pos);
    pos = pos.sub(this.node.position);
    this.direction = pos.normalize();
    var angle = pos.signAngle(cc.v2(1, 0));
    this.node.angle = -(angle * 180 / Math.PI);
  },
  shoot: function shoot() {
    this.rigidBody.type = 2;
    var velocity = this.direction.mulSelf(1800);
    this.rigidBody.linearVelocity = velocity;
  },
  onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
    var joint = this.weldJoint;

    if (joint.enabled) {
      contact.disabled = true;
    }
  },
  // 每次处理完碰撞体接触逻辑时被调用
  onPostSolve: function onPostSolve(contact, selfCollider, otherCollider) {
    score.scoreAdd(1);
    var impulse = contact.getImpulse(); // 获取冲量信息，注意这个信息只有在 onPostSolve 回调中才能获取到

    if (Math.abs(impulse.normalImpulses[0]) < cc.PhysicsManager.PTM_RATIO) return;
    var joint = this.weldJoint;

    if (joint.enabled) {
      joint.enabled = false;
      return;
    }

    if (otherCollider.node.name == "arrow" || otherCollider.tag == 1) {
      return;
    }

    var arrowBody = selfCollider.body;
    var targetBody = otherCollider.body;
    var worldManifold = contact.getWorldManifold(); // 将 arrowBody 本地坐标系下的点转换为世界坐标系下的点

    var points = worldManifold.points;
    var point = arrowBody.getLocalPoint(points[0]);

    if (point.x < 54) {
      return;
    }

    var worldCoordsAnchorPoint = arrowBody.getWorldPoint(cc.v2(0, 0));
    joint.connectedBody = targetBody;
    joint.anchor = arrowBody.getLocalPoint(worldCoordsAnchorPoint);
    joint.connectedAnchor = targetBody.getLocalPoint(worldCoordsAnchorPoint);
    joint.referenceAngle = arrowBody.node.angle - targetBody.node.angle;
    joint.enabled = true;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxBcnJvdy5qcyJdLCJuYW1lcyI6WyJzY29yZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsImRpcmVjdGlvbiIsInYyIiwicmlnaWRCb2R5IiwiZ2V0Q29tcG9uZW50IiwiUmlnaWRCb2R5Iiwid2VsZEpvaW50IiwiV2VsZEpvaW50Iiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsInZlbG9jaXR5IiwibGluZWFyVmVsb2NpdHkiLCJzcGVlZCIsIm1hZyIsImFuZ2xlIiwic2lnbkFuZ2xlIiwibm9kZSIsIk1hdGgiLCJQSSIsImRyYWdDb25zdGFudCIsIm5vcm1hbGl6ZSIsInBvaW50aW5nRGlyZWN0aW9uIiwiZ2V0V29ybGRWZWN0b3IiLCJmbGlnaHREaXJlY3Rpb24iLCJmbGlnaHRTcGVlZCIsIm5vcm1hbGl6ZVNlbGYiLCJkb3QiLCJkcmFnRm9yY2VNYWduaXR1ZGUiLCJhYnMiLCJnZXRNYXNzIiwiYXJyb3dUYWlsUG9zaXRpb24iLCJnZXRXb3JsZFBvaW50IiwiYXBwbHlGb3JjZSIsIm11bCIsInVwZGF0ZUFycm93Um90YXRpb24iLCJwb3MiLCJwYXJlbnQiLCJjb252ZXJ0VG9Ob2RlU3BhY2VBUiIsInN1YiIsInBvc2l0aW9uIiwic2hvb3QiLCJ0eXBlIiwibXVsU2VsZiIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInNlbGZDb2xsaWRlciIsIm90aGVyQ29sbGlkZXIiLCJqb2ludCIsImVuYWJsZWQiLCJkaXNhYmxlZCIsIm9uUG9zdFNvbHZlIiwic2NvcmVBZGQiLCJpbXB1bHNlIiwiZ2V0SW1wdWxzZSIsIm5vcm1hbEltcHVsc2VzIiwiUGh5c2ljc01hbmFnZXIiLCJQVE1fUkFUSU8iLCJuYW1lIiwidGFnIiwiYXJyb3dCb2R5IiwiYm9keSIsInRhcmdldEJvZHkiLCJ3b3JsZE1hbmlmb2xkIiwiZ2V0V29ybGRNYW5pZm9sZCIsInBvaW50cyIsInBvaW50IiwiZ2V0TG9jYWxQb2ludCIsIngiLCJ3b3JsZENvb3Jkc0FuY2hvclBvaW50IiwiY29ubmVjdGVkQm9keSIsImFuY2hvciIsImNvbm5lY3RlZEFuY2hvciIsInJlZmVyZW5jZUFuZ2xlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLEtBQUssR0FBR0MsT0FBTyxDQUFDLFdBQUQsQ0FBbkI7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsTUFUSyxvQkFTSztBQUNOLFNBQUtDLFNBQUwsR0FBaUJMLEVBQUUsQ0FBQ00sRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQWpCO0FBQ0EsU0FBS0MsU0FBTCxHQUFpQixLQUFLQyxZQUFMLENBQWtCUixFQUFFLENBQUNTLFNBQXJCLENBQWpCO0FBQ0EsU0FBS0MsU0FBTCxHQUFpQixLQUFLRixZQUFMLENBQWtCUixFQUFFLENBQUNXLFNBQXJCLENBQWpCO0FBQ0gsR0FiSTtBQWVMQyxFQUFBQSxLQWZLLG1CQWVJLENBQ1IsQ0FoQkk7QUFrQkxDLEVBQUFBLE1BbEJLLGtCQWtCR0MsRUFsQkgsRUFrQk87QUFDUixRQUFJQyxRQUFRLEdBQUcsS0FBS1IsU0FBTCxDQUFlUyxjQUE5QjtBQUNBLFFBQUlDLEtBQUssR0FBR0YsUUFBUSxDQUFDRyxHQUFULEVBQVo7QUFDQSxRQUFJRCxLQUFLLEtBQUssQ0FBZCxFQUFpQjtBQUNiLFFBQUlFLEtBQUssR0FBR0osUUFBUSxDQUFDSyxTQUFULENBQW1CcEIsRUFBRSxDQUFDTSxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBbkIsQ0FBWjtBQUNBLFNBQUtlLElBQUwsQ0FBVUYsS0FBVixHQUFrQixFQUFFQSxLQUFLLEdBQUcsR0FBUixHQUFjRyxJQUFJLENBQUNDLEVBQXJCLENBQWxCO0FBQ0osUUFBSUMsWUFBWSxHQUFHLEdBQW5CO0FBQ0EsUUFBSW5CLFNBQVMsR0FBR1UsUUFBUSxDQUFDVSxTQUFULEVBQWhCO0FBRUEsUUFBSUMsaUJBQWlCLEdBQUcsS0FBS25CLFNBQUwsQ0FBZW9CLGNBQWYsQ0FBK0IzQixFQUFFLENBQUNNLEVBQUgsQ0FBTyxDQUFQLEVBQVUsQ0FBVixDQUEvQixDQUF4QjtBQUNBLFFBQUlzQixlQUFlLEdBQUcsS0FBS3JCLFNBQUwsQ0FBZVMsY0FBckM7QUFDQSxRQUFJYSxXQUFXLEdBQUdELGVBQWUsQ0FBQ1YsR0FBaEIsRUFBbEI7QUFDQVUsSUFBQUEsZUFBZSxDQUFDRSxhQUFoQjtBQUVBLFFBQUlDLEdBQUcsR0FBR0gsZUFBZSxDQUFDRyxHQUFoQixDQUFvQkwsaUJBQXBCLENBQVY7QUFDQSxRQUFJTSxrQkFBa0IsR0FBRyxDQUFDLElBQUlWLElBQUksQ0FBQ1csR0FBTCxDQUFTRixHQUFULENBQUwsSUFBc0JGLFdBQXRCLEdBQW9DQSxXQUFwQyxHQUFrREwsWUFBbEQsR0FBaUUsS0FBS2pCLFNBQUwsQ0FBZTJCLE9BQWYsRUFBMUY7QUFFQSxRQUFJQyxpQkFBaUIsR0FBRyxLQUFLNUIsU0FBTCxDQUFlNkIsYUFBZixDQUE4QnBDLEVBQUUsQ0FBQ00sRUFBSCxDQUFPLENBQUMsRUFBUixFQUFZLENBQVosQ0FBOUIsQ0FBeEI7QUFDQSxTQUFLQyxTQUFMLENBQWU4QixVQUFmLENBQTJCVCxlQUFlLENBQUNVLEdBQWhCLENBQW9CLENBQUNOLGtCQUFyQixDQUEzQixFQUFxRUcsaUJBQXJFLEVBQXdGLEtBQXhGO0FBQ0gsR0FyQ0k7QUF1Q0xJLEVBQUFBLG1CQXZDSywrQkF1Q2VDLEdBdkNmLEVBdUNvQjtBQUNyQkEsSUFBQUEsR0FBRyxHQUFHLEtBQUtuQixJQUFMLENBQVVvQixNQUFWLENBQWlCQyxvQkFBakIsQ0FBc0NGLEdBQXRDLENBQU47QUFDQUEsSUFBQUEsR0FBRyxHQUFHQSxHQUFHLENBQUNHLEdBQUosQ0FBUSxLQUFLdEIsSUFBTCxDQUFVdUIsUUFBbEIsQ0FBTjtBQUNBLFNBQUt2QyxTQUFMLEdBQWlCbUMsR0FBRyxDQUFDZixTQUFKLEVBQWpCO0FBQ0EsUUFBSU4sS0FBSyxHQUFHcUIsR0FBRyxDQUFDcEIsU0FBSixDQUFjcEIsRUFBRSxDQUFDTSxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBZCxDQUFaO0FBQ0EsU0FBS2UsSUFBTCxDQUFVRixLQUFWLEdBQWtCLEVBQUVBLEtBQUssR0FBRyxHQUFSLEdBQWNHLElBQUksQ0FBQ0MsRUFBckIsQ0FBbEI7QUFDSCxHQTdDSTtBQStDTHNCLEVBQUFBLEtBL0NLLG1CQStDSTtBQUNMLFNBQUt0QyxTQUFMLENBQWV1QyxJQUFmLEdBQXNCLENBQXRCO0FBQ0EsUUFBSS9CLFFBQVEsR0FBRyxLQUFLVixTQUFMLENBQWUwQyxPQUFmLENBQXVCLElBQXZCLENBQWY7QUFDQSxTQUFLeEMsU0FBTCxDQUFlUyxjQUFmLEdBQWdDRCxRQUFoQztBQUNILEdBbkRJO0FBcURMaUMsRUFBQUEsY0FyREssMEJBcURXQyxPQXJEWCxFQXFEb0JDLFlBckRwQixFQXFEa0NDLGFBckRsQyxFQXFEaUQ7QUFDbEQsUUFBSUMsS0FBSyxHQUFHLEtBQUsxQyxTQUFqQjs7QUFDQSxRQUFJMEMsS0FBSyxDQUFDQyxPQUFWLEVBQW1CO0FBQ2ZKLE1BQUFBLE9BQU8sQ0FBQ0ssUUFBUixHQUFtQixJQUFuQjtBQUNIO0FBQ0osR0ExREk7QUE0REw7QUFDQUMsRUFBQUEsV0E3REssdUJBNkRRTixPQTdEUixFQTZEaUJDLFlBN0RqQixFQTZEK0JDLGFBN0QvQixFQTZEOEM7QUFDL0NyRCxJQUFBQSxLQUFLLENBQUMwRCxRQUFOLENBQWUsQ0FBZjtBQUNBLFFBQUlDLE9BQU8sR0FBR1IsT0FBTyxDQUFDUyxVQUFSLEVBQWQsQ0FGK0MsQ0FFWjs7QUFDbkMsUUFBSXBDLElBQUksQ0FBQ1csR0FBTCxDQUFTd0IsT0FBTyxDQUFDRSxjQUFSLENBQXVCLENBQXZCLENBQVQsSUFBc0MzRCxFQUFFLENBQUM0RCxjQUFILENBQWtCQyxTQUE1RCxFQUF1RTtBQUN2RSxRQUFJVCxLQUFLLEdBQUcsS0FBSzFDLFNBQWpCOztBQUVBLFFBQUkwQyxLQUFLLENBQUNDLE9BQVYsRUFBbUI7QUFDZkQsTUFBQUEsS0FBSyxDQUFDQyxPQUFOLEdBQWdCLEtBQWhCO0FBQ0E7QUFDSDs7QUFFRCxRQUFJRixhQUFhLENBQUM5QixJQUFkLENBQW1CeUMsSUFBbkIsSUFBMkIsT0FBM0IsSUFBc0NYLGFBQWEsQ0FBQ1ksR0FBZCxJQUFxQixDQUEvRCxFQUFrRTtBQUM5RDtBQUNIOztBQUVELFFBQUlDLFNBQVMsR0FBR2QsWUFBWSxDQUFDZSxJQUE3QjtBQUNBLFFBQUlDLFVBQVUsR0FBR2YsYUFBYSxDQUFDYyxJQUEvQjtBQUNBLFFBQUlFLGFBQWEsR0FBR2xCLE9BQU8sQ0FBQ21CLGdCQUFSLEVBQXBCLENBakIrQyxDQWlCQTs7QUFDL0MsUUFBSUMsTUFBTSxHQUFHRixhQUFhLENBQUNFLE1BQTNCO0FBQ0EsUUFBSUMsS0FBSyxHQUFHTixTQUFTLENBQUNPLGFBQVYsQ0FBd0JGLE1BQU0sQ0FBQyxDQUFELENBQTlCLENBQVo7O0FBQ0EsUUFBSUMsS0FBSyxDQUFDRSxDQUFOLEdBQVUsRUFBZCxFQUFrQjtBQUNkO0FBQ0g7O0FBRUQsUUFBSUMsc0JBQXNCLEdBQUdULFNBQVMsQ0FBQzVCLGFBQVYsQ0FBd0JwQyxFQUFFLENBQUNNLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUF4QixDQUE3QjtBQUVBOEMsSUFBQUEsS0FBSyxDQUFDc0IsYUFBTixHQUFzQlIsVUFBdEI7QUFDQWQsSUFBQUEsS0FBSyxDQUFDdUIsTUFBTixHQUFlWCxTQUFTLENBQUNPLGFBQVYsQ0FBd0JFLHNCQUF4QixDQUFmO0FBQ0FyQixJQUFBQSxLQUFLLENBQUN3QixlQUFOLEdBQXdCVixVQUFVLENBQUNLLGFBQVgsQ0FBeUJFLHNCQUF6QixDQUF4QjtBQUNBckIsSUFBQUEsS0FBSyxDQUFDeUIsY0FBTixHQUF1QmIsU0FBUyxDQUFDM0MsSUFBVixDQUFlRixLQUFmLEdBQXVCK0MsVUFBVSxDQUFDN0MsSUFBWCxDQUFnQkYsS0FBOUQ7QUFFQWlDLElBQUFBLEtBQUssQ0FBQ0MsT0FBTixHQUFnQixJQUFoQjtBQUVIO0FBOUZJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbInZhciBzY29yZSA9IHJlcXVpcmUoJ0dhbWVTY29yZScpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICB0aGlzLmRpcmVjdGlvbiA9IGNjLnYyKDAsIDApO1xyXG4gICAgICAgIHRoaXMucmlnaWRCb2R5ID0gdGhpcy5nZXRDb21wb25lbnQoY2MuUmlnaWRCb2R5KTtcclxuICAgICAgICB0aGlzLndlbGRKb2ludCA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLldlbGRKb2ludCk7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIGxldCB2ZWxvY2l0eSA9IHRoaXMucmlnaWRCb2R5LmxpbmVhclZlbG9jaXR5O1xyXG4gICAgICAgIGxldCBzcGVlZCA9IHZlbG9jaXR5Lm1hZygpO1xyXG4gICAgICAgIGlmIChzcGVlZCA9PT0gMCkgcmV0dXJuO1xyXG4gICAgICAgICAgICBsZXQgYW5nbGUgPSB2ZWxvY2l0eS5zaWduQW5nbGUoY2MudjIoMSwwKSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5hbmdsZSA9IC0oYW5nbGUgKiAxODAgLyBNYXRoLlBJKTtcclxuICAgICAgICBsZXQgZHJhZ0NvbnN0YW50ID0gMC4xO1xyXG4gICAgICAgIGxldCBkaXJlY3Rpb24gPSB2ZWxvY2l0eS5ub3JtYWxpemUoKTtcclxuXHJcbiAgICAgICAgbGV0IHBvaW50aW5nRGlyZWN0aW9uID0gdGhpcy5yaWdpZEJvZHkuZ2V0V29ybGRWZWN0b3IoIGNjLnYyKCAxLCAwICkgKTtcclxuICAgICAgICBsZXQgZmxpZ2h0RGlyZWN0aW9uID0gdGhpcy5yaWdpZEJvZHkubGluZWFyVmVsb2NpdHk7XHJcbiAgICAgICAgbGV0IGZsaWdodFNwZWVkID0gZmxpZ2h0RGlyZWN0aW9uLm1hZygpO1xyXG4gICAgICAgIGZsaWdodERpcmVjdGlvbi5ub3JtYWxpemVTZWxmKCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgbGV0IGRvdCA9IGZsaWdodERpcmVjdGlvbi5kb3QocG9pbnRpbmdEaXJlY3Rpb24pO1xyXG4gICAgICAgIGxldCBkcmFnRm9yY2VNYWduaXR1ZGUgPSAoMSAtIE1hdGguYWJzKGRvdCkpICogZmxpZ2h0U3BlZWQgKiBmbGlnaHRTcGVlZCAqIGRyYWdDb25zdGFudCAqIHRoaXMucmlnaWRCb2R5LmdldE1hc3MoKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgYXJyb3dUYWlsUG9zaXRpb24gPSB0aGlzLnJpZ2lkQm9keS5nZXRXb3JsZFBvaW50KCBjYy52MiggLTY4LCAwICkgKTtcclxuICAgICAgICB0aGlzLnJpZ2lkQm9keS5hcHBseUZvcmNlKCBmbGlnaHREaXJlY3Rpb24ubXVsKC1kcmFnRm9yY2VNYWduaXR1ZGUpLCBhcnJvd1RhaWxQb3NpdGlvbiwgZmFsc2UgKTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlQXJyb3dSb3RhdGlvbihwb3MpIHtcclxuICAgICAgICBwb3MgPSB0aGlzLm5vZGUucGFyZW50LmNvbnZlcnRUb05vZGVTcGFjZUFSKHBvcyk7XHJcbiAgICAgICAgcG9zID0gcG9zLnN1Yih0aGlzLm5vZGUucG9zaXRpb24pO1xyXG4gICAgICAgIHRoaXMuZGlyZWN0aW9uID0gcG9zLm5vcm1hbGl6ZSgpO1xyXG4gICAgICAgIGxldCBhbmdsZSA9IHBvcy5zaWduQW5nbGUoY2MudjIoMSwwKSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gLShhbmdsZSAqIDE4MCAvIE1hdGguUEkpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzaG9vdCAoKSB7XHJcbiAgICAgICAgdGhpcy5yaWdpZEJvZHkudHlwZSA9IDI7XHJcbiAgICAgICAgbGV0IHZlbG9jaXR5ID0gdGhpcy5kaXJlY3Rpb24ubXVsU2VsZigxODAwKTtcclxuICAgICAgICB0aGlzLnJpZ2lkQm9keS5saW5lYXJWZWxvY2l0eSA9IHZlbG9jaXR5O1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkJlZ2luQ29udGFjdCAoY29udGFjdCwgc2VsZkNvbGxpZGVyLCBvdGhlckNvbGxpZGVyKSB7XHJcbiAgICAgICAgbGV0IGpvaW50ID0gdGhpcy53ZWxkSm9pbnQ7XHJcbiAgICAgICAgaWYgKGpvaW50LmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgY29udGFjdC5kaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyDmr4/mrKHlpITnkIblroznorDmkp7kvZPmjqXop6bpgLvovpHml7booqvosIPnlKhcclxuICAgIG9uUG9zdFNvbHZlIChjb250YWN0LCBzZWxmQ29sbGlkZXIsIG90aGVyQ29sbGlkZXIpIHtcclxuICAgICAgICBzY29yZS5zY29yZUFkZCgxKTtcclxuICAgICAgICBsZXQgaW1wdWxzZSA9IGNvbnRhY3QuZ2V0SW1wdWxzZSgpOy8vIOiOt+WPluWGsumHj+S/oeaBr++8jOazqOaEj+i/meS4quS/oeaBr+WPquacieWcqCBvblBvc3RTb2x2ZSDlm57osIPkuK3miY3og73ojrflj5bliLBcclxuICAgICAgICBpZiAoTWF0aC5hYnMoaW1wdWxzZS5ub3JtYWxJbXB1bHNlc1swXSkgPCBjYy5QaHlzaWNzTWFuYWdlci5QVE1fUkFUSU8pIHJldHVybjtcclxuICAgICAgICBsZXQgam9pbnQgPSB0aGlzLndlbGRKb2ludDtcclxuXHJcbiAgICAgICAgaWYgKGpvaW50LmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgam9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob3RoZXJDb2xsaWRlci5ub2RlLm5hbWUgPT0gXCJhcnJvd1wiIHx8IG90aGVyQ29sbGlkZXIudGFnID09IDEpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGFycm93Qm9keSA9IHNlbGZDb2xsaWRlci5ib2R5O1xyXG4gICAgICAgIGxldCB0YXJnZXRCb2R5ID0gb3RoZXJDb2xsaWRlci5ib2R5O1xyXG4gICAgICAgIGxldCB3b3JsZE1hbmlmb2xkID0gY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCk7Ly8g5bCGIGFycm93Qm9keSDmnKzlnLDlnZDmoIfns7vkuIvnmoTngrnovazmjaLkuLrkuJbnlYzlnZDmoIfns7vkuIvnmoTngrlcclxuICAgICAgICBsZXQgcG9pbnRzID0gd29ybGRNYW5pZm9sZC5wb2ludHM7XHJcbiAgICAgICAgbGV0IHBvaW50ID0gYXJyb3dCb2R5LmdldExvY2FsUG9pbnQocG9pbnRzWzBdKTtcclxuICAgICAgICBpZiAocG9pbnQueCA8IDU0KSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB3b3JsZENvb3Jkc0FuY2hvclBvaW50ID0gYXJyb3dCb2R5LmdldFdvcmxkUG9pbnQoY2MudjIoMCwgMCkpO1xyXG4gICAgXHJcbiAgICAgICAgam9pbnQuY29ubmVjdGVkQm9keSA9IHRhcmdldEJvZHk7XHJcbiAgICAgICAgam9pbnQuYW5jaG9yID0gYXJyb3dCb2R5LmdldExvY2FsUG9pbnQod29ybGRDb29yZHNBbmNob3JQb2ludCk7XHJcbiAgICAgICAgam9pbnQuY29ubmVjdGVkQW5jaG9yID0gdGFyZ2V0Qm9keS5nZXRMb2NhbFBvaW50KHdvcmxkQ29vcmRzQW5jaG9yUG9pbnQpO1xyXG4gICAgICAgIGpvaW50LnJlZmVyZW5jZUFuZ2xlID0gYXJyb3dCb2R5Lm5vZGUuYW5nbGUgLSB0YXJnZXRCb2R5Lm5vZGUuYW5nbGU7XHJcblxyXG4gICAgICAgIGpvaW50LmVuYWJsZWQgPSB0cnVlO1xyXG5cclxuICAgIH1cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------
