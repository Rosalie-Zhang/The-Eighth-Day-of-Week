// let scoreInfo = {
//     time : 30,
//     hitscore : 0,
//     scoreAdd : function(k){
//         this.hitscore +=k;
//     },
// };
module.exports = {
    time : 60,
    hitscore : 0,
    scoreAdd : function(k){
        this.hitscore+=k;
    }
};
