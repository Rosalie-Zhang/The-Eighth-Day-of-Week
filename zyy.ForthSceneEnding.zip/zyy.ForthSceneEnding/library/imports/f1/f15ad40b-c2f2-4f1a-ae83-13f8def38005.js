"use strict";
cc._RF.push(module, 'f15adQLwvJPGq6DE/je84AF', 'turnTo_test');
// Script/turnTo_test.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  toScene: function toScene() {
    cc.director.loadScene("scene_test");
  }
});

cc._RF.pop();