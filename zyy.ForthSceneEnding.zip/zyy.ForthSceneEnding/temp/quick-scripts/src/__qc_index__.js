
require('./assets/Script/bad_ending');
require('./assets/Script/fakegood_ending');
require('./assets/Script/good_ending');
require('./assets/Script/label - test');
require('./assets/Script/label');
require('./assets/Script/music');
require('./assets/Script/turnTo_4');
require('./assets/Script/turnTo_test');
