
require('./assets/scripts/Back');
require('./assets/scripts/Box');
require('./assets/scripts/Collision');
require('./assets/scripts/CollisionCallback');
require('./assets/scripts/GoOutside');
require('./assets/scripts/MainController');
require('./assets/scripts/Physize');
require('./assets/scripts/Rigid body');
