// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },
   toSceneTest1: function(){
      cc.director.loadScene("scene_test1")
     },
   toSceneTest2: function(){
      cc.director.loadScene("scene_test2")
   },
   toSceneTest3: function(){
      cc.director.loadScene("scene_test3")
   },
   toSceneTest4: function(){
      cc.director.loadScene("scene_test4")
   },
   toSceneTest5: function(){
      cc.director.loadScene("scene_test5")
   },
   toScene4: function(){
      cc.director.loadScene("scene4")
     },
   tohome: function(){
      cc.director.loadScene("home")
     },
   toGoodending: function(){
      cc.director.loadScene("good_ending")
   },
   toBadending: function(){
      cc.director.loadScene("bad_ending")
   },
   toFgoodending: function(){
      cc.director.loadScene("fakegood_ending")
   },
   torightanser: function(){
      cc.director.loadScene("right_anser")
   },
   towronganster: function(){
      cc.director.loadScene("wrong_anser")
   },
   tosave: function(){
      cc.director.loadScene("saveScene")
   },
   tohelp: function(){
      cc.director.loadScene("helping")
   },
   todiary_e: function(){
      cc.director.loadScene("diary_e")
   },
   todiary_e1: function(){
      cc.director.loadScene("diary_e1")
   },
   toscene1: function(){
      cc.director.loadScene("firstScene")
   },
   toscenegoodending001: function(){
      cc.director.loadScene("good_ending1")
   },
   toscene4001: function(){
      cc.director.loadScene("scene4.1")
   },
});
