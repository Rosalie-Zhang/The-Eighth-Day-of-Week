
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/textbox.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '76d1azambpFO7SohHcPajrw', 'textbox');
// Scripts/textbox.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var jump_button_1 = require("./jump_button");
var message_1 = require("./message");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Message = /** @class */ (function () {
    function Message(content) {
        this.content = content;
    }
    return Message;
}());
var textbox = /** @class */ (function (_super) {
    __extends(textbox, _super);
    function textbox() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Mscontrol = null;
        _this.jump_button_control = null;
        //消息数组
        _this.msgs = null;
        _this.index = 0;
        return _this;
    }
    textbox.prototype.start = function () {
        var _this = this;
        this.msgs = [
            new Message("来探索一下走廊吧")
        ];
        this.node.on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            if (_this.index <= _this.msgs.length) {
                //如果对话面板没显示，显示
                if (_this.Mscontrol.node.active == false) {
                    _this.Mscontrol.node.active = true;
                }
                //读消息
                var mes = _this.msgs[_this.index++];
                //显示消息
                var world_1 = "";
                var letter_1 = mes.content.split("");
                var _loop_1 = function (i) {
                    setTimeout(function () {
                        world_1 += letter_1[i];
                        _this.Mscontrol.setMessage(world_1);
                    }, 60 * (i));
                };
                for (var i = 0; i < mes.content.length; i++) {
                    _loop_1(i);
                }
            }
            if (_this.jump_button_control.node.active == false) {
                _this.jump_button_control.node.active = true;
            }
        });
    };
    __decorate([
        property(message_1.default)
    ], textbox.prototype, "Mscontrol", void 0);
    __decorate([
        property(jump_button_1.default)
    ], textbox.prototype, "jump_button_control", void 0);
    textbox = __decorate([
        ccclass
    ], textbox);
    return textbox;
}(cc.Component));
exports.default = textbox;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcdGV4dGJveC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjtBQUNsRiw2Q0FBd0M7QUFDeEMscUNBQWdDO0FBQzFCLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRTFDO0lBR0ssaUJBQVksT0FBYztRQUN2QixJQUFJLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQztJQUN4QixDQUFDO0lBQ04sY0FBQztBQUFELENBTkEsQUFNQyxJQUFBO0FBR0Q7SUFBcUMsMkJBQVk7SUFBakQ7UUFBQSxxRUFzQ0M7UUFuQ0csZUFBUyxHQUFTLElBQUksQ0FBQztRQUd2Qix5QkFBbUIsR0FBYSxJQUFJLENBQUM7UUFFckMsTUFBTTtRQUNOLFVBQUksR0FBVyxJQUFJLENBQUM7UUFDcEIsV0FBSyxHQUFRLENBQUMsQ0FBQzs7SUE0Qm5CLENBQUM7SUF6QkcsdUJBQUssR0FBTDtRQUFBLGlCQXdCQztRQXZCRCxJQUFJLENBQUMsSUFBSSxHQUFDO1lBQ04sSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDO1NBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUMsVUFBQyxLQUFLO1lBQ2hELElBQUcsS0FBSSxDQUFDLEtBQUssSUFBRSxLQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQztnQkFDN0IsY0FBYztnQkFDZCxJQUFHLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBRSxLQUFLLEVBQUM7b0JBQ2pDLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQ3JDO2dCQUNELEtBQUs7Z0JBQ0wsSUFBSSxHQUFHLEdBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztnQkFDaEMsTUFBTTtnQkFDTixJQUFJLE9BQUssR0FBUSxFQUFFLENBQUM7Z0JBQ3BCLElBQUksUUFBTSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dDQUMzQixDQUFDO29CQUNMLFVBQVUsQ0FBQzt3QkFDUCxPQUFLLElBQUksUUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNuQixLQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxPQUFLLENBQUMsQ0FBQztvQkFDckMsQ0FBQyxFQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O2dCQUpkLEtBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7NEJBQWxDLENBQUM7aUJBS1I7YUFBQztZQUNILElBQUcsS0FBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxNQUFNLElBQUUsS0FBSyxFQUFDO2dCQUM5QyxLQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7YUFDNUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFsQ0Q7UUFEQyxRQUFRLENBQUMsaUJBQU8sQ0FBQzs4Q0FDSztJQUd2QjtRQURDLFFBQVEsQ0FBQyxxQkFBVyxDQUFDO3dEQUNlO0lBTnBCLE9BQU87UUFEM0IsT0FBTztPQUNhLE9BQU8sQ0FzQzNCO0lBQUQsY0FBQztDQXRDRCxBQXNDQyxDQXRDb0MsRUFBRSxDQUFDLFNBQVMsR0FzQ2hEO2tCQXRDb0IsT0FBTyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuaW1wb3J0IGp1bXBfYnV0dG9uIGZyb20gXCIuL2p1bXBfYnV0dG9uXCI7XHJcbmltcG9ydCBtZXNzYWdlIGZyb20gXCIuL21lc3NhZ2VcIjtcclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5jbGFzcyBNZXNzYWdle1xyXG4gICAgIGNvbnRlbnQ6c3RyaW5nO1xyXG5cclxuICAgICBjb25zdHJ1Y3Rvcihjb250ZW50OnN0cmluZyl7XHJcbiAgICAgICAgdGhpcy5jb250ZW50PWNvbnRlbnQ7XHJcbiAgICAgfVxyXG59XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyB0ZXh0Ym94IGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuICAgIFxyXG4gICAgQHByb3BlcnR5KG1lc3NhZ2UpXHJcbiAgICBNc2NvbnRyb2w6bWVzc2FnZT1udWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShqdW1wX2J1dHRvbilcclxuICAgIGp1bXBfYnV0dG9uX2NvbnRyb2w6anVtcF9idXR0b249bnVsbDtcclxuICAgIFxyXG4gICAgLy/mtojmga/mlbDnu4RcclxuICAgIG1zZ3M6TWVzc2FnZVtdPW51bGw7XHJcbiAgICBpbmRleDpudW1iZXI9MDtcclxuICAgIFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgIHRoaXMubXNncz1bXHJcbiAgICAgICAgbmV3IE1lc3NhZ2UoXCLmnaXmjqLntKLkuIDkuIvotbDlu4rlkKdcIikgXTtcclxuICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTiwoZXZlbnQpPT57XHJcbiAgICAgaWYodGhpcy5pbmRleDw9dGhpcy5tc2dzLmxlbmd0aCl7XHJcbiAgICAgICAgLy/lpoLmnpzlr7nor53pnaLmnb/msqHmmL7npLrvvIzmmL7npLpcclxuICAgICAgICBpZih0aGlzLk1zY29udHJvbC5ub2RlLmFjdGl2ZT09ZmFsc2Upe1xyXG4gICAgICAgICAgICB0aGlzLk1zY29udHJvbC5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8v6K+75raI5oGvXHJcbiAgICAgICAgbGV0IG1lcz10aGlzLm1zZ3NbdGhpcy5pbmRleCsrXTtcclxuICAgICAgICAvL+aYvuekuua2iOaBr1xyXG4gICAgICAgIGxldCB3b3JsZDpzdHJpbmc9XCJcIjtcclxuICAgICAgICBsZXQgbGV0dGVyID0gbWVzLmNvbnRlbnQuc3BsaXQoXCJcIik7XHJcbiAgICAgICAgZm9yKGxldCBpID0gMDsgaSA8IG1lcy5jb250ZW50Lmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgc2V0VGltZW91dCgoKT0+e1xyXG4gICAgICAgICAgICAgICAgd29ybGQgKz0gbGV0dGVyW2ldO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5Nc2NvbnRyb2wuc2V0TWVzc2FnZSh3b3JsZCk7XHJcbiAgICAgICAgICAgIH0sNjAqKGkpKTtcclxuICAgICAgICB9fVxyXG4gICAgICAgaWYodGhpcy5qdW1wX2J1dHRvbl9jb250cm9sLm5vZGUuYWN0aXZlPT1mYWxzZSl7XHJcbiAgICAgICAgdGhpcy5qdW1wX2J1dHRvbl9jb250cm9sLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgIH1cclxuICAgICB9KTsgXHJcbiAgICB9XHJcbn1cclxuXHJcbiAgICAiXX0=