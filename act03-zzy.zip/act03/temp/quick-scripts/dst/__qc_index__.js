
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Scripts/NewScript');
require('./assets/Scripts/a');
require('./assets/Scripts/b');
require('./assets/Scripts/box');
require('./assets/Scripts/canoon');
require('./assets/Scripts/classdoor');
require('./assets/Scripts/coward');
require('./assets/Scripts/door');
require('./assets/Scripts/elevator');
require('./assets/Scripts/jump_button');
require('./assets/Scripts/jump_choice');
require('./assets/Scripts/jump_lingjian');
require('./assets/Scripts/lingjian');
require('./assets/Scripts/message');
require('./assets/Scripts/textbox');
require('./assets/Scripts/textbox2');
require('./assets/Scripts/textbox3');
require('./assets/Scripts/textbox4');
require('./assets/Scripts/textbox5');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();